package com.example.demo;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer2.Claim;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class ClaimTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;
	
	@Test
	void findClaimTest() {
		Claim claim=claimRepo.findClaim(4);
		System.out.println(claim.getClaimNo());
		System.out.println(claim.getReason());
		System.out.println(claim.getClaimDate());
		System.out.println(claim.getClaimStatus());
		System.out.println(claim.getClaimAmt());
		System.out.println(claim.getApproval());
		System.out.println(claim.getPolicyManagement().getPolicyNo());
		System.out.println(claim.getIuser().getUserId());
		
	}

	@Test
	void addClaimTest() {
		Claim claim = new Claim();
		PolicyManagement pm=new PolicyManagement();
		pm.setPolicyNo(1348);
		//claim.setClaimNo(44);
	    claim.setReason("CYCLONE");
	    //String claimD="2021-01-15";
	    Iuser iu=new Iuser();
	    iu.setUserId(507);
	    claim.setPolicyManagement(pm);
	    //Date dateClm=Date.valueOf(claimD);
	    claim.setClaimDate(LocalDate.of(2021, 1, 15));
		claim.setClaimAmt(1270);
		claim.setClaimStatus("Claimed");
		claim.setApproval("Approved");
		claim.setIuser(iu);
		claimRepo.addClaim(claim);
		
	}
	@Test
	void modifyClaimTest() {
		Claim claim = new Claim();
		PolicyManagement pm=new PolicyManagement();
		pm.setPolicyNo(1348);
		claim.setClaimNo(65);
	    claim.setReason("FLOOD");
	    //String claimD="2021-01-15";
	    Iuser iu=new Iuser();
	    iu.setUserId(507);
	    claim.setPolicyManagement(pm);
	    //Date dateClm=Date.valueOf(claimD);
	    claim.setClaimDate(LocalDate.of(2021, 1, 15));
		claim.setClaimAmt(1270);
		claim.setClaimStatus("Claimed");
		claim.setApproval("Approved");
		claim.setIuser(iu);
		claimRepo.modifyClaim(claim);
	}
	
	@Test
    void deleteClaim()  // DELETE USER
    {
        claimRepo.removeClaim(65);
        System.out.println("Remmove Successful");
    }
	
	  @Test 
	  void findClaimsTest() { 
		  Set<Claim> claim = claimRepo.findClaims(); 
		  for (Claim e: claim) { 
			  System.out.println(e.getClaimNo());
				System.out.println(e.getReason());
				System.out.println(e.getClaimDate());
				System.out.println(e.getClaimStatus());
				System.out.println(e.getClaimAmt());
				System.out.println(e.getApproval());
				System.out.println(e.getPolicyManagement().getPolicyNo());
				System.out.println(e.getIuser().getUserId());
	          System.out.println("-----------------"); } }
	  
	  @Test 
	  void findClaimsByPolicyNo() { 
		  Set<Claim> claim = claimRepo.findClaimsByPolicy_No(1348); 
		  for (Claim e: claim) { 
			  System.out.println(e.getClaimNo());
				System.out.println(e.getReason());
				System.out.println(e.getClaimDate());
				System.out.println(e.getClaimStatus());
				System.out.println(e.getClaimAmt());
				System.out.println(e.getApproval());
				System.out.println(e.getPolicyManagement().getPolicyNo());
				System.out.println(e.getIuser().getUserId());
	          System.out.println("-----------------"); } }
	  @Test 
      void findClaimsByClaimStatusTest() { 
          Set<Claim> claim = claimRepo.findClaimsByClaimStatus("CLAIMED"); 
          for (Claim e: claim) { 
              System.out.println(e.getClaimNo());
                System.out.println(e.getReason());
                System.out.println(e.getClaimDate());
                System.out.println(e.getClaimStatus());
                System.out.println(e.getClaimAmt());
                System.out.println(e.getApproval());
                System.out.println(e.getPolicyManagement().getPolicyNo());
                System.out.println(e.getIuser().getUserId());
              System.out.println("-----------------"); } }
	  @Test 
      void findClaimsByUserIdTest() { 
          Set<Claim> claim = claimRepo.findClaimsByUser_Id(503); 
          for (Claim e: claim) { 
              System.out.println(e.getClaimNo());
                System.out.println(e.getReason());
                System.out.println(e.getClaimDate());
                System.out.println(e.getClaimStatus());
                System.out.println(e.getClaimAmt());
                System.out.println(e.getApproval());
                System.out.println(e.getPolicyManagement().getPolicyNo());
                System.out.println(e.getIuser().getUserId());
              System.out.println("-----------------"); } }
	  
}