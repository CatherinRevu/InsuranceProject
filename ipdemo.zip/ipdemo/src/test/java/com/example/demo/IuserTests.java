package com.example.demo;



import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class IuserTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;
	
	
	@Test
	void findIuser() {
		Iuser iu=iuserRepo.findIuser(502);
		System.out.println(iu.getUserId());
		System.out.println(iu.getName());
		System.out.println(iu.getEmail());
		System.out.println(iu.getPassword());
		System.out.println(iu.getDob());
		System.out.println(iu.getContact());
		System.out.println(iu.getStreet());
		System.out.println(iu.getCity());
		System.out.println(iu.getDistrict());
		System.out.println(iu.getState());
		System.out.println(iu.getPincode());
		
		
	}

	@Test
	void addIuserTest() {
		Iuser addiu = new Iuser();
		
		
		addiu.setUserId(addiu.getUserId());
		addiu.setName("Deepak");
		addiu.setEmail("d@gmail.com");
		addiu.setPassword("Deeva45516");
		//String str="1999-09-12";
        //LocalDate date1=Date.valueOf(str);
		addiu.setDob(LocalDate.of(1999, 9, 12));
		addiu.setContact(1326410251);
		addiu.setStreet("begumpet");
		addiu.setCity("Rangareddy");
		addiu.setDistrict("efb");
		addiu.setState("TS");
		addiu.setPincode(531248);
		
		iuserRepo.addIuser(addiu);
	}
	@Test
	void ModifyIuserTest() {
		
		Iuser iu=new Iuser();
		iu.setUserId(45);
		iu.setName("Insane");
		iu.setEmail("insane@gmail.com");
		iu.setPassword("insane565");
		//String str="2021-05-20";
        //Date date1=Date.valueOf(str);
		iu.setDob(LocalDate.of(1999, 9, 12));
		iu.setContact(45648);
		iu.setStreet("banajara hills");
		iu.setCity("secunderbad");
		iu.setDistrict("maharam");
		iu.setState("ranaga reddy");
		iu.setPincode(848654);
		
		iuserRepo.modifyIuser(iu);
	}
	
	@Test
    void deleteIuser()  // DELETE USER
    {
        iuserRepo.removeIuser(45);
        System.out.println("Remmove Successful");
    }
	
	  @Test 
	  void findIusersTest() { 
		  Set<Iuser> iuset = iuserRepo.findIusers(); 
		  for (Iuser e: iuset) { 
			  System.out.println(e.getUserId());
	          System.out.println(e.getPassword());
	          System.out.println(e.getName());
	          System.out.println("-----------------"); } }
	 	 
}