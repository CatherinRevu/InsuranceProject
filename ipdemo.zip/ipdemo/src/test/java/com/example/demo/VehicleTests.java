package com.example.demo;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.Vehicle;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class VehicleTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;

	
	@Test
	void findVehicleTest() {
		Vehicle v=vRepo.findVehicle(80128);
		System.out.println(v.getRegNo());
		System.out.println(v.getAge());
		System.out.println(v.getChasisNo());
		System.out.println(v.getDriversLicense());
		System.out.println(v.getEngNo());
		System.out.println(v.getEngType());
		System.out.println(v.getModel());
		System.out.println(v.getPurchaseDate());
		System.out.println(v.getTypeOfVehicle());
		System.out.println(v.getIuser().getUserId());
	}

	@Test
	void addVehicleTest() {
		Vehicle v=new Vehicle();
		Iuser usr= new Iuser();
		usr.setUserId(501);
		//v.setRegNo(5555);
		v.setAge(3);
		v.setChasisNo("gfytd65498rhhf");
		v.setDriversLicense("df57845dfg");
		v.setEngNo("1xx2545");
		v.setEngType("petrol");
		v.setModel("dggt");
		//String str2="1996-12-30";
		//Date date1=Date.valueOf(str2);
		v.setPurchaseDate(LocalDate.of(1996, 12, 30));
		v.setTypeOfVehicle("2 Wheeler");
		v.setIuser(usr);
		vRepo.addVehicle(v);
		System.out.println("added succesfully");
	}
	@Test
	void ModifyVehicleTest() {
		
		Vehicle v=new Vehicle();
		Iuser usr= new Iuser();
		usr.setUserId(507);
		v.setRegNo(63);
		v.setAge(5);
		v.setChasisNo("TD5tg8gt5g8");
		v.setDriversLicense("df57845dfg");
		v.setEngNo("1xx2545");
		v.setEngType("diesel");
		v.setModel("dggt");
		//String str2="1996-12-30";
		//Date date1=Date.valueOf(str2);
		v.setPurchaseDate(LocalDate.of(1996, 12, 30));
		v.setTypeOfVehicle("2 Wheeler");
		v.setIuser(usr);
		vRepo.modifyVehicle(v);
		System.out.println("modified succesfully");
	}
	
	@Test
    void deleteVehicle()  // DELETE USER
    {
        vRepo.removeVehicle(63);
        System.out.println("Remmove Successful");
    }
	
	  @Test 
	  void findVehiclesTest() { 
		  Set<Vehicle> vset = vRepo.findVehicles(); 
		  for (Vehicle e: vset) { 
			  System.out.println(e.getRegNo());
				System.out.println(e.getAge());
				System.out.println(e.getChasisNo());
				System.out.println(e.getDriversLicense());
				System.out.println(e.getEngNo());
				System.out.println(e.getEngType());
				System.out.println(e.getModel());
				System.out.println(e.getPurchaseDate());
				System.out.println(e.getTypeOfVehicle());
				System.out.println(e.getIuser().getUserId());
	          System.out.println("-----------------"); } }
	 	 
}