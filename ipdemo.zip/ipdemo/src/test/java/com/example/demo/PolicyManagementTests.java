package com.example.demo;


import java.sql.Date;
import java.time.LocalDate;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.Policy;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.Vehicle;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class PolicyManagementTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;
	
	
	@Test
	void findPurchasedPolicyTest() {
		PolicyManagement poliM=pmRepo.findPolicyManagement(4753);
		System.out.println(poliM.getPolicy().getPolicyId());
		System.out.println(poliM.getVehicle().getRegNo());
		System.out.println(poliM.getAmount());
		System.out.println(poliM.getPayment());
		System.out.println(poliM.getPolicyNo());
		System.out.println(poliM.getPolicyIssueDate());
		System.out.println(poliM.getDuration());
		System.out.println(poliM.getPolicyStatus());
		System.out.println(poliM.getPolicyExpireDate());
		System.out.println(poliM.getIuser().getUserId());
	}

	@Test
	void addPolicyManagementTest() {
		PolicyManagement addpurpol = new PolicyManagement();
		//Vehicle v=vRepo.findVehicle(55);
		
		Policy pol = new Policy();
		pol.setPolicyId(303);
		Iuser Ius = new Iuser();
		Ius.setUserId(122);
		Vehicle v=new Vehicle();
		v.setRegNo(125);
		addpurpol.setPolicy(pol);
		addpurpol.setVehicle(v);
		addpurpol.setAmount(2000);
		addpurpol.setPayment("YES");
		//String issueD="2016-11-09";
        //Date dateIss=Date.valueOf(issueD);
        addpurpol.setPolicyIssueDate(LocalDate.of(2016, 11, 9));
		addpurpol.setDuration(1);
		addpurpol.setPolicyStatus("ACTIVE");
		//String expireD="2017-11-09";
        //Date dateEx=Date.valueOf(expireD);
        addpurpol.setPolicyExpireDate(LocalDate.of(2017, 11, 9));
        addpurpol.setIuser(Ius);
		
		pmRepo.addPolicyManagement(addpurpol);
	}
	@Test
	void ModifyPurchasedPolicyTest() {
		
		PolicyManagement addpurpol = new PolicyManagement();
		//Vehicle v=vRepo.findVehicle(55);
		addpurpol.setPolicyNo(129);
		Policy pol = new Policy();
		pol.setPolicyId(303);
		Iuser Ius = new Iuser();
		Ius.setUserId(122);
		Vehicle v=new Vehicle();
		v.setRegNo(125);
		addpurpol.setPolicy(pol);
		addpurpol.setVehicle(v);
		addpurpol.setAmount(2000);
		addpurpol.setPayment("YES");
		//String issueD="2016-11-09";
        //Date dateIss=Date.valueOf(issueD);
        addpurpol.setPolicyIssueDate(LocalDate.of(2016, 11, 9));
		addpurpol.setDuration(1);
		addpurpol.setPolicyStatus("NOT ACTIVE");
		//String expireD="2017-11-09";
        //Date dateEx=Date.valueOf(expireD);
        addpurpol.setPolicyIssueDate(LocalDate.of(2017, 11, 9));
        addpurpol.setIuser(Ius);
		
		pmRepo.modifyPolicyManagement(addpurpol);
	}
	
	@Test
    void deletePurchasedPolicy()  // DELETE USER
    {
        pmRepo.removePolicyManagement(129);
        System.out.println("Remove Successful");
    }
	
	  @Test 
	  void findPolicyManagementsTest() { 
		  Set<PolicyManagement> pmset = pmRepo.findPolicyManagements(); 
		  for (PolicyManagement e: pmset) { 
			  System.out.println(e.getPolicy().getPolicyId());
	          System.out.println(e.getVehicle().getRegNo());
	          System.out.println(e.getAmount());
	          System.out.println(e.getPayment());
	          System.out.println(e.getPolicyNo());
	          System.out.println(e.getPolicyIssueDate());
	          System.out.println(e.getDuration());
	          System.out.println(e.getPolicyStatus());
	          System.out.println(e.getPolicyExpireDate());
	          System.out.println(e.getIuser().getUserId());
	          System.out.println("-----------------"); } }
	  @Test 
	  void findPolicyManagementsbyUserIdTest() { 
		  Set<PolicyManagement> ppuset = pmRepo.findPolicyManagementsbyUserId(502); 
		  for (PolicyManagement e: ppuset) { 
			  Policy p=new Policy();
			  System.out.println("POLICY ID IS 	: "+e.getPolicy().getPolicyId());
	          System.out.println("REGISTER NO IS 		: "+e.getVehicle().getRegNo());
	          System.out.println("AMOUNT IS 		: "+e.getAmount());
	          System.out.println("PAYMENT STATUS IS 	: "+e.getPayment());
	          System.out.println("POLICY NO IS 		: "+e.getPolicyNo());
	          System.out.println("POLICY ISSUE DATE IS 	: "+e.getPolicyIssueDate());
	          System.out.println("DURATION IS 		: "+e.getDuration());
	          System.out.println("POLICY STATUS IS 		: "+e.getPolicyStatus());
	          System.out.println("POLICY EXPIRE DATE IS 	: "+e.getPolicyExpireDate());
	          System.out.println("USER ID IS 		: "+e.getIuser().getUserId());
	          System.out.println("-----------------"); } }
	 	 
}


