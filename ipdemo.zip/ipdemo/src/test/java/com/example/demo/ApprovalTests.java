package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;

import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class ApprovalTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;

	
	@Test
	void findApprovalTest() {
		Approval ap=appRepo.findApproval(1001);
		Admin ad= new Admin();
		
		System.out.println(ap.getApprovalNo());
		System.out.println(ap.getAdmin().getAdminId());
		System.out.println(ap.getPolicyManagement().getPolicyNo());
		System.out.println(ap.getClaim().getClaimNo());
		System.out.println(ap.getClaimApproval());
		System.out.println(ap.getClaimStatus());
		System.out.println(ap.getIuser().getUserId());
		

	}

	@Test
	void addApprovalTest() {
		//
		//appRepo.delete(//)
		Approval approval = new Approval();
		Admin ad= new Admin();
		ad.setAdminId(101);
		Claim cl= new Claim();
		cl.setClaimNo(7);
		PolicyManagement pm=new PolicyManagement();
		pm.setPolicyNo(1348);
		Iuser iu= new Iuser();
		iu.setUserId(507);
		//approval.setApprovalNo(2004);
		approval.setAdmin(ad);
		approval.setClaim(cl);
		approval.setClaimStatus("claimed");
		approval.setPolicyManagement(pm);
		approval.setClaimApproval("Approved");
		approval.setIuser(iu);
		//approval.setPassword("arnav123");
		System.out.println("added succesfully");
		
        appRepo.addApproval(approval);

	}
	@Test
	void ModifyApprovalTest() {
		
		Approval approval = new Approval();
		Admin ad= new Admin();
		ad.setAdminId(101);
		Claim cl= new Claim();
		cl.setClaimNo(7);
		PolicyManagement pm=new PolicyManagement();
		pm.setPolicyNo(1348);
		Iuser iu= new Iuser();
		iu.setUserId(507);
		approval.setApprovalNo(70);
		approval.setAdmin(ad);
		approval.setClaim(cl);
		approval.setClaimStatus("claimed");
		approval.setPolicyManagement(pm);
		approval.setClaimApproval("pending");
		approval.setIuser(iu);
		appRepo.modifyApproval(approval);
	}
	
	@Test
    void deleteApprovalTest()  // DELETE USER
    {
        appRepo.removeApproval(2004);
        System.out.println("Remove Successful");
    }
	
	  @Test 
	  void findApprovalsTest() { 
		  Set<Approval> appset = appRepo.findApprovals(); 
		  for (Approval ap: appset) { 
	        System.out.println("-----------------");
	        System.out.println(ap.getApprovalNo());
			System.out.println(ap.getAdmin().getAdminId());
			System.out.println(ap.getPolicyManagement().getPolicyNo());
			System.out.println(ap.getClaim().getClaimNo());
			System.out.println(ap.getClaimApproval());
			System.out.println(ap.getClaimStatus());
			System.out.println(ap.getIuser().getUserId());
			}
		  }
	 	 
}