package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;

import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class AdminTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;

	
	@Test
	void findAdmin() {
		Admin ad=adRepo.findAdmin(61);
		System.out.println(ad.getAdminId());
		System.out.println(ad.getName());
		System.out.println(ad.getPassword());
	}

	@Test
	void addAdminTest() {
		Admin addAdm = new Admin();
		
		//addAdm.setAdminId(503);
		addAdm.setPassword("nbvvi1");
		addAdm.setName("adam");
		adRepo.addAdmin(addAdm);
		System.out.println("added succesfully");
	}
	@Test
	void ModifyAdminTest() {
		
		Admin ad=new Admin();
		ad.setAdminId(60);
		ad.setName("arnav");
		ad.setPassword("ravi456");
		adRepo.modifyAdmin(ad);
	}
	
	@Test
    void deleteAdmin()  // DELETE USER
    {
        adRepo.removeAdmin(5);
        System.out.println("Remmove Successful");
    }
	
	  @Test 
	  void findAdminsTest() { 
		  Set<Admin> adset = adRepo.findAdmins(); 
		  for (Admin e: adset) { 
			  System.out.println(e.getAdminId());
	          System.out.println(e.getPassword());
	          System.out.println(e.getName());
	          System.out.println("-----------------"); } }
	 	 


		/*
		 * @Test void findPurchasedPolicyTest() { PurchasedPolicy
		 * purcpoli=ppRepo.findPurchasedPolicy(1348);
		 * System.out.println(purcpoli.getPolicy().getPolicyId());
		 * System.out.println(purcpoli.getVehicle().);
		 * System.out.println(purcpoli.getAmount());
		 * System.out.println(purcpoli.getPayment());
		 * System.out.println(purcpoli.getPolicyNo());
		 * System.out.println(purcpoli.getPolicyIssueDate());
		 * System.out.println(purcpoli.getDuration());
		 * System.out.println(purcpoli.getPolicyExpireDate());
		 * System.out.println(purcpoli.getIuser().getUserId()); }
		 */
}

