package com.example.demo;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Policy;
import com.example.demo.layer3.AdminRepoImpl;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;

@SpringBootTest
class PolicyTests {

	@Autowired
	AdminRepository adRepo;
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	ApprovalRepository appRepo;
	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyRepository polRepo;
	@Autowired
	PolicyManagementRepository pmRepo;

	
	@Test
	void findPolicy() {
		Policy p=polRepo.findPolicy(201);
		System.out.println(p.getPolicyId());
		System.out.println(p.getPolicyName());
		System.out.println(p.getDuration());
	}

	@Test
	void addPolicyTest() {
		Policy addp = new Policy();
		
		//addAdm.setAdminId(503);
		addp.setDuration(2);
		addp.setPolicyName("OWE_2WHEELER_2");
				polRepo.addPolicy(addp);
	}
	@Test
	void modifyPolicyTest() {
		
		Policy p=new Policy();
		p.setPolicyId(66);
		p.setPolicyName("OWE_2WHEELER_4");
		p.setDuration(4);
		polRepo.modifyPolicy(p);
	}
	
	@Test
    void deletePolicy()  // DELETE USER
    {
        polRepo.removePolicy(66);
        System.out.println("Remmove Successful");
    }
	
	  @Test 
	  void findPoliciesTest() { 
		  Set<Policy> pset = polRepo.findPolicies(); 
		  for (Policy e: pset) { 
			  System.out.println(e.getPolicyId());
	          System.out.println(e.getDuration());
	          System.out.println(e.getPolicyName());
	          System.out.println("-----------------"); } }
	 	 
	  @Test
	  void findPolicyByDur() {
		  Set<Policy> pset = polRepo.findPolicyByDuration(2); 
		  for (Policy e: pset) { 
			  System.out.println(e.getPolicyId());
	          System.out.println(e.getDuration());
	          System.out.println(e.getPolicyName());
	          System.out.println("-----------------"); }
	  }
	  @Test
	  void findPolicyByName(){
		  Set<Policy> pset = polRepo.findPolicyByName("OWE 2WHEELER_2"); 
		  for (Policy p: pset) {
			System.out.println(p.getPolicyId());
			System.out.println(p.getPolicyName());
			System.out.println(p.getDuration());
		}
	  
	  }
}