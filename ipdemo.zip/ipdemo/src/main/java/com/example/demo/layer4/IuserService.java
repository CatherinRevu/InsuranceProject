package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public interface IuserService {//same as DeparmentDAO

	String addIuserService(Iuser UdRef) throws AlreadyExistsException ;   //C - add/create
	Iuser findIuserService(int Udno) throws NotFoundException;     //R - find/reading
	Set<Iuser> findIusersService();     //R - find all/reading all
	String modifyIuserService(Iuser UdRef) throws NotFoundException; //U - modify/update
	String removeIuserService(int Udno) throws NotFoundException; //D - remove/delete
	Iuser authentication(int userId, String password) throws NotFoundException;
	

}

