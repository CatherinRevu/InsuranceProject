package com.example.demo.layer2.dto;

import java.io.Serializable;
import javax.persistence.*;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.PolicyManagement;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;


public class VehicleDTO{


	private int regNo;

	private int age;


	private String chasisNo;

	
	private String driversLicense;

	
	private String engNo;

	
	private String engType;

	private String model;

	private LocalDate purchaseDate=LocalDate.now();

	private String typeOfVehicle;

	private int userId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public VehicleDTO() {
	}

	public int getRegNo() {
		return this.regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getChasisNo() {
		return this.chasisNo;
	}

	public void setChasisNo(String chasisNo) {
		this.chasisNo = chasisNo;
	}

	public String getDriversLicense() {
		return this.driversLicense;
	}

	public void setDriversLicense(String driversLicense) {
		this.driversLicense = driversLicense;
	}

	public String getEngNo() {
		return this.engNo;
	}

	public void setEngNo(String engNo) {
		this.engNo = engNo;
	}

	public String getEngType() {
		return this.engType;
	}

	public void setEngType(String engType) {
		this.engType = engType;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public LocalDate getPurchaseDate() {
		return this.purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getTypeOfVehicle() {
		return this.typeOfVehicle;
	}

	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}



}