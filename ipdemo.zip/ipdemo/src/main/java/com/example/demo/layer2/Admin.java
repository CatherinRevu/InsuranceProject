package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Set;


/**
 * The persistent class for the "ADMIN" database table.
 * 
 */
@Entity
@Table(name="ADMIN")
@NamedQuery(name="Admin.findAll", query="SELECT a FROM Admin a")
public class Admin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ADMIN_ID")
	private int adminId;

	private String name;

	private String password;

	//bi-directional many-to-one association to Approval
	@OneToMany(mappedBy="admin", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Approval> approvals;

	public Admin() {
	}

	public int getAdminId() {
		return this.adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	//@JsonIgnore
	public Set<Approval> getApprovals() {
		return this.approvals;
	}

	public void setApprovals(Set<Approval> approvals) {
		this.approvals = approvals;
	}

	public Approval addApproval(Approval approval) {
		getApprovals().add(approval);
		approval.setAdmin(this);

		return approval;
	}

	public Approval removeApproval(Approval approval) {
		getApprovals().remove(approval);
		approval.setAdmin(null);

		return approval;
	}

}