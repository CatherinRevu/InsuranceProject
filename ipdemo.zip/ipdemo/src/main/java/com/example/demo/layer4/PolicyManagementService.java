package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.dto.PolicyManagementDTO;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public interface PolicyManagementService {
	
	String addPolicyManagementService(PolicyManagementDTO pmDTO) throws AlreadyExistsException ;   //C - add/create
	PolicyManagement findPolicyManagementService(int pmno) throws NotFoundException;     //R - find/reading
	Set<PolicyManagement> findPolicyManagementServices();     //R - find all/reading all
	String modifyPolicyManagementService(PolicyManagement pmRef) throws NotFoundException; //U - modify/update
	String removePolicyManagementService(int pmno) throws NotFoundException; //D - remove/delete
	Set<PolicyManagement> findPolicyManagementsbyUserIdServices(int pmno);
}

