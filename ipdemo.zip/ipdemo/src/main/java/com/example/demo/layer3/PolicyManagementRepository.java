package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.PolicyManagement;
//import com.example.demo.layer2.PurchasedPolicy;

@Repository
public interface PolicyManagementRepository {//same as DeparmentDAO

	void addPolicyManagement(PolicyManagement pmRef);   //C - add/create
	PolicyManagement findPolicyManagement(int pmno);     //R - find/reading
	Set<PolicyManagement> findPolicyManagements();     //R - find all/reading all
	void modifyPolicyManagement(PolicyManagement pmRef); //U - modify/update
	void removePolicyManagement(int pmno); //D - remove/delete
	Set<PolicyManagement> findPolicyManagementsbyUserId(int pmno);


}