package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class IuserServiceImpl implements IuserService{//isA
	
	@Autowired
	IuserRepository iuserRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addIuserService(Iuser UdRef) throws AlreadyExistsException {//usesA
		try {
			iuserRepo.addIuser(UdRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("User already exists");
		}
		return "user added sucessfully";
		

	}
	
	@Override
	public Iuser findIuserService(int Udno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Iuser UdObj = entityManager.find(Iuser.class, Udno);
		System.out.println("found user");
		
		return iuserRepo.findIuser(Udno);
		
	}

	@Override
	public Set<Iuser> findIusersService() {
     			
		return iuserRepo.findIusers();
	}

	@Override
	public String modifyIuserService(Iuser UdRef) throws NotFoundException {
		Iuser u = iuserRepo.findIuser(UdRef.getUserId());
		if (u!=null) {
			iuserRepo.modifyIuser(UdRef);
		}
		else
		{
			throw new NotFoundException("user Not Found");
		}
     return"user modified sucessfully";
	}

	@Override
	public String removeIuserService(int Udno) throws NotFoundException {
		
		Iuser u = iuserRepo.findIuser(Udno);
		if (u!=null) {
			iuserRepo.removeIuser(u.getUserId());
		}
		else
		{
			throw new NotFoundException("user Not Found");
		}
     return "user deleted sucessfully";
	}

	@Override
	public Iuser authentication(int userId, String password) throws NotFoundException
	{
		String pwd;
		Iuser iuser=iuserRepo.findIuser(userId);
		
		if(iuser!=null)
		{
			pwd=iuser.getPassword();
		}
		else
		{
			throw new NotFoundException("user not found");
		}
		if(!pwd.equalsIgnoreCase(password))
		{
			throw new NotFoundException("Invalid password");
		}
		return iuser;
	}
	
	
}

