package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.PolicyManagement;




@Repository("pmRepo")
public class PolicyManagementRepoImpl implements PolicyManagementRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addPolicyManagement(PolicyManagement pmRef) {//usesA
		entityManager.persist(pmRef);
		

	}
	
	@Transactional
	public PolicyManagement findPolicyManagement(int pmno) {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//PolicyManagement PMObj = entityManager.find(PolicyManagement.class, pmno);
		//System.out.println(PMObj);
		return entityManager.find(PolicyManagement.class, pmno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<PolicyManagement> findPolicyManagements() {
		Set<PolicyManagement> policymanagementSet;
		policymanagementSet = new HashSet<PolicyManagement>();
		
			String queryString = "from PolicyManagement";
			Query query = entityManager.createQuery(queryString);
			policymanagementSet =new HashSet(query.getResultList());
					
		return policymanagementSet;
		
	}

	@Transactional
	public void modifyPolicyManagement(PolicyManagement pmRef) {
		entityManager.merge(pmRef);

	}

	@Transactional
	public void removePolicyManagement(int pmno) {
		PolicyManagement pmTemp = entityManager.find(PolicyManagement.class,pmno);
		entityManager.remove(pmTemp);
		
	}
	@SuppressWarnings({"unchecked","rawtypes"})
	@Transactional
	public Set<PolicyManagement> findPolicyManagementsbyUserId(int pmno) {
		Set<PolicyManagement> pmSet;
		pmSet = new HashSet<PolicyManagement>();
		Query query = entityManager.createNativeQuery("select * from policy_management where user_id=:myuser_id",PolicyManagement.class).setParameter("myuser_id", pmno);
		pmSet =new HashSet(query.getResultList());
					
		return pmSet;
		
	}

}


