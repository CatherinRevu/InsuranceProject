package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.Policy;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.Vehicle;
import com.example.demo.layer2.dto.PolicyManagementDTO;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class PolicyManagementServiceImpl implements PolicyManagementService{//isA
	
	@Autowired
	PolicyManagementRepository pmRepo;
    @Autowired
	IuserRepository iuserRepo;
    @Autowired
    VehicleRepository vRepo;
    @Autowired
    PolicyRepository polRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addPolicyManagementService(PolicyManagementDTO pmDTO) throws AlreadyExistsException {//usesA
		try {
			PolicyManagement polMan=new PolicyManagement();
			polMan.setAmount(pmDTO.getAmount());
			polMan.setPayment(pmDTO.getPayment());
			polMan.setPolicyIssueDate(pmDTO.getPolicyIssueDate());
			polMan.setDuration(pmDTO.getDuration());
			polMan.setPolicyExpireDate(pmDTO.getPolicyExpireDate());
			polMan.setPolicyStatus(pmDTO.getPolicyStatus());
			
			Iuser user=iuserRepo.findIuser(pmDTO.getUserId());
			//user.getPolicyManagements().add(polMan);
			polMan.setIuser(user);
			//iuserRepo.modifyIuser(user);
			
			Policy pol=polRepo.findPolicy(pmDTO.getPolicyId());
			//pol.getPolicyManagements().add(polMan);
			polMan.setPolicy(pol);
			//polRepo.modifyPolicy(pol);
			
			
			Vehicle vehicle=vRepo.findVehicle(pmDTO.getRegNo());
			//vehicle.getPolicyManagements().add(polMan);
			polMan.setVehicle(vehicle);
			//vRepo.modifyVehicle(vehicle);
			
			pmRepo.addPolicyManagement(polMan);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("Policy Management already exists");
		}
		return "Policy Managmenet added sucessfully";
		

	}
	
	@Override
	public PolicyManagement findPolicyManagementService(int pmno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Iuser UdObj = entityManager.find(Iuser.class, Udno);
		System.out.println("found Policy Management");
		
		return pmRepo.findPolicyManagement(pmno);
		
	}

	@Override
	public Set<PolicyManagement> findPolicyManagementServices() {
     			
		return pmRepo.findPolicyManagements();
	}

	@Override
	public String modifyPolicyManagementService(PolicyManagement pmRef) throws NotFoundException {
		PolicyManagement pm = pmRepo.findPolicyManagement(pmRef.getPolicyNo());
		if (pm!=null) {
			pmRepo.modifyPolicyManagement(pmRef);
		}
		else
		{
			throw new NotFoundException("Policy Management Not Found");
		}
     return"Policy Management modified sucessfully";
	}

	@Override
	public String removePolicyManagementService(int pmno) throws NotFoundException {
		
		PolicyManagement pm = pmRepo.findPolicyManagement(pmno);
		if (pm!=null) {
			pmRepo.removePolicyManagement(pm.getPolicyNo());
		}
		else
		{
			throw new NotFoundException("PolicyManagement Not Found");
		}
     return "PolicyManagement deleted sucessfully";
	}
	@Override
	public Set<PolicyManagement> findPolicyManagementsbyUserIdServices(int pmno) {
     			
		return pmRepo.findPolicyManagements();
	}

}
