package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the POLICY_MANAGEMENT database table.
 * 
 */
@Entity
@Table(name="POLICY_MANAGEMENT")
@NamedQuery(name="PolicyManagement.findAll", query="SELECT p FROM PolicyManagement p")
public class PolicyManagement{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="POLICY_NO")
	private int policyNo;

	private int amount;

	private int duration;

	private String payment;

	
	@Column( columnDefinition="DATE",name="POLICY_EXPIRE_DATE")
	private LocalDate policyExpireDate=LocalDate.now();

	@Column(columnDefinition="DATE",name="POLICY_ISSUE_DATE")
	private LocalDate policyIssueDate=LocalDate.now();

	@Column(name="POLICY_STATUS")
	private String policyStatus;

	//bi-directional many-to-one association to Iuser
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Iuser iuser;



	@OneToMany(mappedBy ="policyManagement",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Claim> claims;
	
	@OneToOne(mappedBy="policyManagement")	
	private Approval approval;

	@ManyToOne
	@JoinColumn(name ="POLICY_ID")
	private Policy policy;
	
	@ManyToOne
	@JoinColumn(name ="REG_NO")
	private Vehicle vehicle;

	public PolicyManagement() {
	}

	public int getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public int getAmount() {
		return this.amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getPayment() {
		return this.payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public LocalDate getPolicyExpireDate() {
		return this.policyExpireDate;
	}

	public void setPolicyExpireDate(LocalDate policyExpireDate) {
		this.policyExpireDate = policyExpireDate;
	}

	public LocalDate getPolicyIssueDate() {
		return this.policyIssueDate;
	}

	public void setPolicyIssueDate(LocalDate policyIssueDate) {
		this.policyIssueDate = policyIssueDate;
	}

	public String getPolicyStatus() {
		return this.policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	
	@JsonIgnore
	public Iuser getIuser() {
		return this.iuser;
	}

	public void setIuser(Iuser iuser) {
		this.iuser = iuser;
	}
    


	public Approval getApproval() {
		return this.approval;
	}

	public void setApproval(Approval approval) {
		this.approval = approval;
	}
	@JsonIgnore
	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	public Set<Claim> getClaims() {
		return this.claims;
	}

	public void setClaims(Set<Claim> claims) {
		this.claims = claims;
	}

	public Claim addClaim(Claim claim) {
		getClaims().add(claim);
		claim.setPolicyManagement(this);

		return claim;
	}

	public Claim removeClaim(Claim claim) {
		getClaims().remove(claim);
		claim.setPolicyManagement(null);

		return claim;
	}
	@JsonIgnore
	public Policy getPolicy() {
		return policy;
	}

	public void setPolicy(Policy policy) {
		this.policy = policy;
	}

}