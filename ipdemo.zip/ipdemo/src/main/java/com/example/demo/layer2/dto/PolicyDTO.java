package com.example.demo.layer2.dto;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


public class PolicyDTO{

	private int policyId;

	private int duration;

	private String policyName;

	public PolicyDTO() {
	}

	public int getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getPolicyName() {
		return this.policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

}