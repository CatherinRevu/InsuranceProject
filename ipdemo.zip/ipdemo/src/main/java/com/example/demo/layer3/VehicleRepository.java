package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Vehicle;

@Repository
public interface VehicleRepository {//same as DeparmentDAO

	void addVehicle(Vehicle VRef);   //C - add/create
	Vehicle findVehicle(int Regno);     //R - find/reading
	Set<Vehicle> findVehicles();     //R - find all/reading all
	void modifyVehicle(Vehicle VRef); //U - modify/update
	void removeVehicle(int Regno); //D - remove/delete

}
