package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Claim;
import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.dto.ClaimDTO;
import com.example.demo.layer3.ClaimRepository;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyManagementRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;
import com.example.demo.layer4.exceptions.AlreadyExistsException;


@Service
public class ClaimServiceImpl implements ClaimService {//isA

	@Autowired
	ClaimRepository claimRepo;
	@Autowired
	IuserRepository iuserRepo;
	@Autowired
	PolicyManagementRepository polManRepo;
	
	@Override//no need of begin transaction and commit rollback
	public String addClaimService(ClaimDTO cDTO) throws AlreadyExistsException {//usesA
		try {
			
			Claim claim=new Claim();
			claim.setApproval(cDTO.getApproval());
			claim.setReason(cDTO.getReason());
			claim.setClaimDate(cDTO.getClaimDate());
			claim.setClaimStatus(cDTO.getClaimStatus());
			claim.setClaimAmt(cDTO.getClaimAmt());
			
			Iuser user=iuserRepo.findIuser(cDTO.getUserId());
			//user.getClaims().add(claim);
			claim.setIuser(user);
			
			PolicyManagement polMan= polManRepo.findPolicyManagement(cDTO.getPolicyNo());
			//polMan.getClaims().add(claim);
			claim.setPolicyManagement(polMan);
			//polManRepo.modifyPolicyManagement(polMan);
			
			claimRepo.addClaim(claim);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("User already exists");
		}
		return "claim added sucessfully";
		//entityManager.persist(CdRef);
		

	}
	
	@Override
	public Claim findClaimService(int Cdno) throws NotFoundException{//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Claim CdObj = entityManager.find(Claim.class, Cdno);
		System.out.println("Claim found");
		return claimRepo.findClaim(Cdno);
		
	}

	@Override
	public Set<Claim> findClaimsService() {

		return claimRepo.findClaims();
		
	}

	@Override
	public String modifyClaimService(Claim CdRef) throws NotFoundException {
		Claim c = claimRepo.findClaim(CdRef.getClaimNo());
		if (c!=null) {
			claimRepo.modifyClaim(CdRef);
		}
		else
		{
			throw new NotFoundException("user Not Found");
		}
     return"claim modified sucessfully";
		//entityManager.merge(CdRef);

	}

	@Override
	public String removeClaimService(int Cdno) throws NotFoundException{
		Claim c = claimRepo.findClaim(Cdno);
		if (c!=null) {
			claimRepo.removeClaim(c.getClaimNo());
		}
		else
		{
			throw new NotFoundException("user Not Found");
		}
     return"user modified sucessfully";
		
	}
	@Override
    public Set<Claim> findClaimsByPolicy_NoService(int Cdno) {
                   
        return claimRepo.findClaimsByPolicy_No(Cdno);
	}
	@Override
	public Set<Claim> findClaimsByClaimStatusService(String cstatus) {
					
		return claimRepo.findClaimsByClaimStatus(cstatus);
		
	}
	
	@Override
	public Set<Claim> findClaimsByUser_IdService(int Cdno){
          
	        return claimRepo.findClaimsByUser_Id(Cdno);
	}
	}

	
	



