package com.example.demo.layer5;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Vehicle;
import com.example.demo.layer2.dto.VehicleDTO;
import com.example.demo.layer4.VehicleService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class VehicleController {

	@Autowired
	VehicleService vehicleServ;
	
	@GetMapping(path="/getVehicle/{myregno}")
	@ResponseBody
	public ResponseEntity<Vehicle> getVehicle(@PathVariable("myregno") Integer Vdno) throws NotFoundException {
		System.out.println("Vehicle Controller....Understanding client and talking to service layer...");
		Vehicle vehicle=null;
		
		vehicle = vehicleServ.findVehicleService(Vdno);
			if(vehicle==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(vehicle);
			}
		
	}
	
	@PostMapping(path="/addVehicle")
	public String addVehicle(@RequestBody VehicleDTO vehicle) {
		
		System.out.println("Vehicle Controller....Understanding client and talking to service layer...");
		/*
		 * Vehicle u=new Vehicle(); u.setTypeOfVehicle(vehicle.getTypeOfVehicle());
		 * u.setModel(vehicle.getModel()); u.setEngType(vehicle.getEngType());
		 * u.setDriversLicense(vehicle.getDriversLicense());
		 * u.setPurchaseDate(vehicle.getPurchaseDate()); u.setAge(vehicle.getAge());
		 * u.setEngNo(vehicle.getEngNo()); u.setChasisNo(vehicle.getChasisNo());
		 * u.setIuser(vehicle.getIuser());
		 */
	
		
		 String stmsg = null;
		try {
			System.out.println(vehicle.getUserId());
			System.out.println(vehicle.getPurchaseDate());
			stmsg = vehicleServ.addVehicleService(vehicle);
		} 
	 catch (AlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	
	
}