package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.Vehicle;
import com.example.demo.layer2.dto.VehicleDTO;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;


@Service
public interface VehicleService {//same as DeparmentDAO

	String addVehicleService(VehicleDTO vDTO) throws AlreadyExistsException ;   //C - add/create
	Vehicle findVehicleService(int Vdno) throws NotFoundException;     //R - find/reading
	Set<Vehicle> findVehicleService();     //R - find all/reading all
	String modifyVehicleService(Vehicle VdRef) throws NotFoundException; //U - modify/update
	String removeVehicleService(int Vdno) throws NotFoundException; //D - remove/delete

}
