package com.example.demo.layer2.dto;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;



public class PolicyManagementDTO {

	private int policyNo;

	private int amount;

	private int duration;

	private String payment;

	private LocalDate policyExpireDate=LocalDate.now();

	private LocalDate policyIssueDate=LocalDate.now();

	private String policyStatus;

	private int userId;

	private int policyId;

	private int regNo;

	public PolicyManagementDTO() {
	}

	public int getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public int getAmount() {
		return this.amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getPayment() {
		return this.payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

	public LocalDate getPolicyExpireDate() {
		return this.policyExpireDate;
	}

	public void setPolicyExpireDate(LocalDate policyExpireDate) {
		this.policyExpireDate = policyExpireDate;
	}

	public LocalDate getPolicyIssueDate() {
		return this.policyIssueDate;
	}

	public void setPolicyIssueDate(LocalDate policyIssueDate) {
		this.policyIssueDate = policyIssueDate;
	}

	public String getPolicyStatus() {
		return this.policyStatus;
	}

	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public int getRegNo() {
		return regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}
	

}