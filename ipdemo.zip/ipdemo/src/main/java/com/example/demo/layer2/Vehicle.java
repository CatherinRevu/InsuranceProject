package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the VEHICLE database table.
 * 
 */
@Entity
@Table(name="VEHICLE")
@NamedQuery(name="Vehicle.findAll", query="SELECT v FROM Vehicle v")
public class Vehicle{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="REG_NO")
	private int regNo;

	private int age;

	@Column(name="CHASIS_NO")
	private String chasisNo;

	@Column(name="DRIVERS_LICENSE")
	private String driversLicense;

	@Column(name="ENG_NO")
	private String engNo;

	@Column(name="ENG_TYPE")
	private String engType;

	private String model;

	@Column(columnDefinition = "DATE",name="PURCHASE_DATE")
	private LocalDate purchaseDate=LocalDate.now();

	@Column(name="TYPE_OF_VEHICLE")
	private String typeOfVehicle;

	//bi-directional many-to-one association to Iuser
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Iuser iuser;

	@OneToMany(mappedBy ="vehicle",fetch =FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<PolicyManagement> policyManagements;

	public Vehicle() {
	}

	public int getRegNo() {
		return this.regNo;
	}

	public void setRegNo(int regNo) {
		this.regNo = regNo;
	}

	public int getAge() {
		return this.age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getChasisNo() {
		return this.chasisNo;
	}

	public void setChasisNo(String chasisNo) {
		this.chasisNo = chasisNo;
	}

	public String getDriversLicense() {
		return this.driversLicense;
	}

	public void setDriversLicense(String driversLicense) {
		this.driversLicense = driversLicense;
	}

	public String getEngNo() {
		return this.engNo;
	}

	public void setEngNo(String engNo) {
		this.engNo = engNo;
	}

	public String getEngType() {
		return this.engType;
	}

	public void setEngType(String engType) {
		this.engType = engType;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public LocalDate getPurchaseDate() {
		return this.purchaseDate;
	}

	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public String getTypeOfVehicle() {
		return this.typeOfVehicle;
	}

	public void setTypeOfVehicle(String typeOfVehicle) {
		this.typeOfVehicle = typeOfVehicle;
	}

	@JsonIgnore
	public Iuser getIuser() {
		return this.iuser;
	}

	public void setIuser(Iuser iuser) {
		this.iuser = iuser;
	}
	public Set<PolicyManagement> getPolicyManagements() {
		return this.policyManagements;
	}

	public void setPolicyManagements(Set<PolicyManagement> policyManagements) {
		this.policyManagements = policyManagements;
	}

	public PolicyManagement addPolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().add(policyManagement);
		policyManagement.setVehicle(this);

		return policyManagement;
	}

	public PolicyManagement removePolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().remove(policyManagement);
		policyManagement.setVehicle(null);

		return policyManagement;
	}
	

}