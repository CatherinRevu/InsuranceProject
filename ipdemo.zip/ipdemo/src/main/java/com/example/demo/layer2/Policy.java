package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;


/**
 * The persistent class for the POLICY database table.
 * 
 */
@Entity
@Table(name="POLICY")
@NamedQuery(name="Policy.findAll", query="SELECT p FROM Policy p")
public class Policy{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="POLICY_ID")
	private int policyId;

	private int duration;

	@Column(name="POLICY_NAME")
	private String policyName;

	//bi-directional one-to-one association to PolicyManagement
	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name="POLICY_ID", referencedColumnName="POLICY_ID") private
	 * PolicyManagement policyManagement;
	 */
	@OneToMany(mappedBy ="policy",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<PolicyManagement> policyManagements;
	
	public Policy() {
	}

	public int getPolicyId() {
		return this.policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public int getDuration() {
		return this.duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getPolicyName() {
		return this.policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	
	public Set<PolicyManagement> getPolicyManagements() {
		return this.policyManagements;
	}

	public void setPolicyManagements(Set<PolicyManagement> policyManagements) {
		this.policyManagements = policyManagements;
	}

	public PolicyManagement addPolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().add(policyManagement);
		policyManagement.setPolicy(this);

		return policyManagement;
	}

	public PolicyManagement removePolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().remove(policyManagement);
		policyManagement.setPolicy(null);

		return policyManagement;
	}
	

}