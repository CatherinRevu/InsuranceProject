package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Iuser;

@Repository
public interface IuserRepository {//same as DeparmentDAO

	void addIuser(Iuser UdRef);   //C - add/create
	Iuser findIuser(int Udno);     //R - find/reading
	Set<Iuser> findIusers();     //R - find all/reading all
	void modifyIuser(Iuser UdRef); //U - modify/update
	void removeIuser(int Udno); //D - remove/delete

}

