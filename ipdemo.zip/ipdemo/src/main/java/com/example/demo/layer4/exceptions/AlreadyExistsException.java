package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class AlreadyExistsException extends Throwable{
	public AlreadyExistsException(String msg) {
		super(msg);
	}
}
