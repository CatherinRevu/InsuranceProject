package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;




@Repository("apRepo")
public class ApprovalRepoImpl implements ApprovalRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addApproval(Approval ApRef) {//usesA
		entityManager.persist(ApRef);
		

	}
	
	@Transactional
	public Approval findApproval(int Apno){//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Approval AdObj = entityManager.find(Approval.class, Apno);
		System.out.println("Approval found");
		return entityManager.find(Approval.class, Apno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Approval> findApprovals() {
		Set<Approval> approvalSet;
		approvalSet = new HashSet<Approval>();
		
			String queryString = "from Approval";
			Query query = entityManager.createQuery(queryString);
			approvalSet =new HashSet(query.getResultList());
					
		return approvalSet;
		
	}

	@Transactional
	public void modifyApproval(Approval ApRef) {
		entityManager.merge(ApRef);

	}

	@Transactional
	public void removeApproval(int Apno) {
		Approval ApTemp = entityManager.find(Approval.class,Apno);
		entityManager.remove(ApTemp);
		
	}


}