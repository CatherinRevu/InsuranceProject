package com.example.demo.layer5;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer4.IuserService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class IuserController {

	@Autowired
	IuserService iuserServ;
	
	@GetMapping(path="/getIuser/{myuid}")
	@ResponseBody
	public ResponseEntity<Iuser> getIuser(@PathVariable("myuid") Integer Udno) throws NotFoundException {
		System.out.println("user Controller....Understanding client and talking to service layer...");
		Iuser iuser=null;
		
			iuser = iuserServ.findIuserService(Udno);
			if(iuser==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(iuser);
			}
		
	}
	
	@PostMapping(path="/addIuser")
	public String addIuser(@RequestBody Iuser iuser) {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		
		
		 String stmsg = null;
		try {
			stmsg = iuserServ.addIuserService(iuser);
		} 
	 catch (AlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	
	@PostMapping(path="/loginUser")
	public Iuser authentication(@RequestBody Iuser user) throws NotFoundException
	{
		System.out.println("user controller understanding whats happening");
		String stmsg=null;
		Iuser foundUser = iuserServ.authentication(user.getUserId(),user.getPassword());
		return foundUser;
		
	}

	
	
}