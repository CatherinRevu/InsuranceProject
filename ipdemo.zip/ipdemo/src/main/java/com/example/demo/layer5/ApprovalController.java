package com.example.demo.layer5;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;

import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer4.ApprovalService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;

import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class ApprovalController {

	@Autowired
	ApprovalService approvalServ;
	
	@GetMapping(path="/getApproval/{myapno}")
	@ResponseBody
	public ResponseEntity<Approval> getApproval(@PathVariable("myapno") Integer Apno) throws NotFoundException {
		System.out.println("approval Controller....Understanding client and talking to service layer...");
		Approval approval=null;
		
			approval = approvalServ.findApprovalService(Apno);
			if(approval==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(approval);
			}
		
	}
	


@PutMapping(path="/modifyApproval")
	public String modifyApproval(@RequestBody Approval approval)throws NotFoundException {
		System.out.println("Approval Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = approvalServ.modifyApprovalService(approval);
		} 
		catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
}