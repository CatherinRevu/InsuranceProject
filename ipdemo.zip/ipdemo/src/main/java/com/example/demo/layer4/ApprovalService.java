package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Approval;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public interface ApprovalService {//same as DeparmentDAO

	String addApprovalService(Approval ApRef) throws AlreadyExistsException ;   //C - add/create
	Approval findApprovalService(int Apno) throws NotFoundException;     //R - find/reading
	Set<Approval> findApprovalsService();     //R - find all/reading all
	String modifyApprovalService(Approval ApRef) throws NotFoundException; //U - modify/update
	String removeApprovalService(int APno) throws NotFoundException; //D - remove/delete

}
