package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;
import com.example.demo.layer2.dto.ClaimDTO;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public interface ClaimService {//same as DeparmentDAO

	String addClaimService(ClaimDTO CdRef) throws AlreadyExistsException;   //C - add/create
	Claim findClaimService(int Cdno) throws NotFoundException;     //R - find/reading
	Set<Claim> findClaimsService();     //R - find all/reading all
	String modifyClaimService(Claim CdRef) throws NotFoundException; //U - modify/update
	String removeClaimService(int Cdno) throws NotFoundException; //D - remove/delete
	Set<Claim> findClaimsByPolicy_NoService(int Cdno) throws NotFoundException;
	Set<Claim> findClaimsByClaimStatusService(String cstatus) throws NotFoundException;
	Set<Claim> findClaimsByUser_IdService(int Cdno) throws NotFoundException;

}
