package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Admin;




@Repository
public class AdminRepoImpl implements AdminRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addAdmin(Admin AdRef) {//usesA
		entityManager.persist(AdRef);
		

	}
	
	@Transactional
	public Admin findAdmin(int Adno) {//producesA Department obj
		//System.out.println("-----------");
		System.out.println("Department repo....NO scope of bussiness logic here...");
		return entityManager.find(Admin.class, Adno);
		
	}
	
	
	
	  @Override 
	  public Set<Admin> findAdmins(int Adno){ 
		  Set<Admin> adminSet; Query
	      query= entityManager.createQuery("from admin",Admin.class).setParameter("AdRef",Adno);
		  adminSet=new HashSet(query.getResultList()); 
		  return adminSet;
	  
	  }
	 
	
	

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Admin> findAdmins() {
		Set<Admin> adminSet;
		adminSet = new HashSet<Admin>();
		
			String queryString = "from Admin";
			Query query = entityManager.createQuery(queryString);
			adminSet =new HashSet(query.getResultList());
					
		return adminSet;
		
	}

	@Transactional
	public void modifyAdmin(Admin AdRef) {
		entityManager.merge(AdRef);

	}

	@Transactional
	public void removeAdmin(int Adno) {
		Admin AdTemp = entityManager.find(Admin.class,Adno);
		entityManager.remove(AdTemp);
		
	}

}