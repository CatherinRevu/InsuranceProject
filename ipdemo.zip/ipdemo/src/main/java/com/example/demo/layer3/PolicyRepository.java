package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Policy;

@Repository
public interface PolicyRepository {//same as DeparmentDAO

	void addPolicy(Policy pRef);   //C - add/create
	Policy findPolicy(int pno);     //R - find/reading
	Set<Policy> findPolicies();     //R - find all/reading all
	void modifyPolicy(Policy pRef); //U - modify/update
	void removePolicy(int pno);
	Set<Policy> findPolicyByDuration(int pno);
	Set<Policy> findPolicyByName(String pname);
}//D - remove/delete
