package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Vehicle;




@Repository("vRepo")
public class VehicleRepoImpl implements VehicleRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addVehicle(Vehicle VRef) {//usesA
		entityManager.persist(VRef);
		

	}
	
	@Transactional
	public Vehicle findVehicle(int Regno) {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Vehicle VObj = entityManager.find(Vehicle.class, Regno);
		//System.out.println(VObj);
		return entityManager.find(Vehicle.class, Regno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Vehicle> findVehicles() {
		Set<Vehicle> vehicleSet;
		vehicleSet = new HashSet<Vehicle>();
		
			String queryString = "from Vehicle";
			Query query = entityManager.createQuery(queryString);
			vehicleSet =new HashSet(query.getResultList());
					
		return vehicleSet;
		
	}

	@Transactional
	public void modifyVehicle(Vehicle VRef) {
		entityManager.merge(VRef);

	}

	@Transactional
	public void removeVehicle(int Regno) {
		Vehicle VTemp = entityManager.find(Vehicle.class,Regno);
		entityManager.remove(VTemp);
		
	}

}

