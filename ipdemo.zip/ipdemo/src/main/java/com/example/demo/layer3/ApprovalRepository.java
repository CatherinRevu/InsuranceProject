package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;

@Repository
public interface ApprovalRepository {//same as DeparmentDAO

	void addApproval(Approval ApRef);   //C - add/create
	Approval findApproval(int Apno);     //R - find/reading
	Set<Approval> findApprovals();     //R - find all/reading all
	void modifyApproval(Approval ApRef); //U - modify/update
	void removeApproval(int Apno); //D - remove/delete

}