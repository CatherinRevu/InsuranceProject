package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Admin;
import com.example.demo.layer3.AdminRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class AdminServiceImpl implements AdminService{//isA
	
	@Autowired
	AdminRepository adRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addAdminService(Admin AdRef) throws AlreadyExistsException {//usesA
		try {
			adRepo.addAdmin(AdRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("Admin already exists");
		}
		return "admin added sucessfully";
		

	}
	
	@Override
	public Admin findAdminService(int Adno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Admin adObj = entityManager.find(Admin.class, Adno);
		System.out.println("found admin");
		
		return adRepo.findAdmin(Adno);
		
	}

	@Override
	public Set<Admin> findAdminsService() {
     			
		return adRepo.findAdmins();
	}

	@Override
	public String modifyAdminService(Admin AdRef) throws NotFoundException {
		Admin a = adRepo.findAdmin(AdRef.getAdminId());
		if (a!=null) {
			adRepo.modifyAdmin(AdRef);
		}
		else
		{
			throw new NotFoundException("admin Not Found");
		}
     return "admin modified sucessfully";
	}

	@Override
	public String removeAdminService(int Adno) throws NotFoundException {
		
		Admin a = adRepo.findAdmin(Adno);
		if (a!=null) {
			adRepo.removeAdmin(a.getAdminId());
		}
		else
		{
			throw new NotFoundException("admin Not Found");
		}
     return "admin deleted sucessfully";
	}
}
