package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Approval;
import com.example.demo.layer3.ApprovalRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class ApprovalServiceImpl implements ApprovalService{//isA
	
	@Autowired
	ApprovalRepository ApprovalRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addApprovalService(Approval ApRef) throws AlreadyExistsException {//usesA
		try {
			ApprovalRepo.addApproval(ApRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("Approval already exists");
		}
		return "Approval added sucessfully";
		

	}
	
	@Override
	public Approval findApprovalService(int Apno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Iuser UdObj = entityManager.find(Iuser.class, Udno);
		System.out.println(" Approval found");
		
		return ApprovalRepo.findApproval(Apno);
		
	}

	@Override
	public Set<Approval> findApprovalsService() {
     			
		return ApprovalRepo.findApprovals();
	}

	@Override
	public String modifyApprovalService(Approval ApRef) throws NotFoundException {
		Approval ap = ApprovalRepo.findApproval(ApRef.getApprovalNo());
		if (ap!=null) {
			ApprovalRepo.modifyApproval(ApRef);
		}
		else
		{
			throw new NotFoundException("Approval Not Found");
		}
     return"Approval modified sucessfully";
	}

	@Override
	public String removeApprovalService(int Apno) throws NotFoundException {
		
		Approval ap = ApprovalRepo.findApproval(Apno);
		if (ap!=null) {
			ApprovalRepo.removeApproval(ap.getApprovalNo());
		}
		else
		{
			throw new NotFoundException("Approval Not Found");
		}
     return "Approval deleted sucessfully";
	}

}
