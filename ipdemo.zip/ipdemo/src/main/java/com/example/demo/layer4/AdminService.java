package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Service;


import com.example.demo.layer2.Admin;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public interface AdminService {//same as DeparmentDAO

	String addAdminService(Admin AdRef) throws AlreadyExistsException;  //C - add/create
	Admin findAdminService(int Adno) throws NotFoundException;    //R - find/reading
	Set<Admin> findAdminsService();     //R - find all/reading all
	String modifyAdminService(Admin AdRef) throws NotFoundException; //U - modify/update
	String removeAdminService(int Adno) throws NotFoundException;
}//D - remove/delete
