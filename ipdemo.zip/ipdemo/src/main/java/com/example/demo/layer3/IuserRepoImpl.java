package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Iuser;




@Repository
public class IuserRepoImpl implements IuserRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addIuser(Iuser UdRef) {//usesA
		entityManager.persist(UdRef);
		

	}
	
	@Transactional
	public Iuser findIuser(int Udno) {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Iuser UdObj = entityManager.find(Iuser.class, Udno);
		System.out.println("found user");
		return entityManager.find(Iuser.class, Udno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Iuser> findIusers() {
		Set<Iuser> iuserSet;
		iuserSet = new HashSet<Iuser>();
		
			String queryString = "from Iuser";
			Query query = entityManager.createQuery(queryString);
			iuserSet =new HashSet(query.getResultList());
					
		return iuserSet;
		
	}

	@Transactional
	public void modifyIuser(Iuser UdRef) {
		entityManager.merge(UdRef);

	}

	@Transactional
	public void removeIuser(int Udno) {
		Iuser UdTemp = entityManager.find(Iuser.class,Udno);
		entityManager.remove(UdTemp);
		
	}

}

