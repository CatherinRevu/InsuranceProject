package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.layer2.Policy;
import com.example.demo.layer4.PolicyService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class PolicyController {

	@Autowired
	PolicyService policyServ;
	
	@GetMapping(path="/getpolicy/{mypol}")
	@ResponseBody
	public ResponseEntity<Policy> getPolicy(@PathVariable("mypol") Integer pno) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Policy policy=null;
		
			policy = policyServ.findPolicyService(pno);
			if(policy==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(policy);
			}
		
	}
	
	@PostMapping(path="/addpolicy")
	public String addPolicy(@RequestBody Policy policy) {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Policy pol=new Policy();
		
		pol.setDuration(policy.getDuration());
		pol.setPolicyName(policy.getPolicyName());
		
		
		 String stmsg = null;
		try {
			stmsg = policyServ.addPolicyService(pol);
		} 
	 catch (AlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	@PutMapping(path="/modifypolicy")
	public String modifyPolicy(@RequestBody Policy policy)throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = policyServ.modifyPolicyService(policy);
		} 
		catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	@GetMapping(path="/getpolicies")
	@ResponseBody
	public Set<Policy> getAllPolicies() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		Set<Policy> policyset = policyServ.findPoliciesService();
		return policyset;
		
	}
	@GetMapping(path="/getpolicybyduration/{mydur}")
	@ResponseBody
	public ResponseEntity<Set<Policy>> getPolicyByDuration(@PathVariable("mydur") Integer pno) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Set<Policy> policy=null;
		
			policy = policyServ.findPolicyByDurationService(pno);
			if(policy==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(policy);
			}
		
	}
	@GetMapping(path="/getpolicybyname/{myname}")
	@ResponseBody
	public ResponseEntity<Set<Policy>> getPolicyByName(@PathVariable("myname") String pname) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Set<Policy> policy=null;
		
			policy = policyServ.findPolicyByNameService(pname);
			if(policy==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(policy);
			}
		
	}
	
}