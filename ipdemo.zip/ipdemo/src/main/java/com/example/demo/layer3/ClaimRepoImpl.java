package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Claim;


	


@Repository
public class ClaimRepoImpl implements ClaimRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addClaim(Claim CdRef) {//usesA
		entityManager.persist(CdRef);
		

	}
	
	@Transactional
	public Claim findClaim(int Cdno) {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Claim CdObj = entityManager.find(Claim.class, Cdno);
		System.out.println("Claim found");
		return entityManager.find(Claim.class, Cdno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Claim> findClaims() {
		Set<Claim> claimSet;
		claimSet = new HashSet<Claim>();
		
			String queryString = "from Claim";
			Query query = entityManager.createQuery(queryString);
			claimSet = new HashSet(query.getResultList());
					
		return claimSet;
		
	}

	@Transactional
	public void modifyClaim(Claim CdRef) {
		entityManager.merge(CdRef);

	}

	@Transactional
	public void removeClaim(int Cdno) {
		Claim CdTemp = entityManager.find(Claim.class,Cdno);
		entityManager.remove(CdTemp);
		
	}
	@SuppressWarnings("unchecked")
    @Transactional
    public Set<Claim> findClaimsByPolicy_No(int Cdno) {
        Set<Claim> claimSet;
        claimSet = new HashSet<Claim>();
            Query query = entityManager.createNativeQuery("select * from claim where POLICY_NO=:myno",Claim.class).setParameter("myno",Cdno);
            claimSet = new HashSet(query.getResultList());
                    
        return claimSet;
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Claim> findClaimsByClaimStatus(String cstatus) {
		Set<Claim> claimbystSet;
		claimbystSet = new HashSet<Claim>();
		
			
			Query query = entityManager.createNativeQuery("select * from claim where CLAIM_STATUS=:mystatus",Claim.class).setParameter("mystatus",cstatus);
			claimbystSet = new HashSet(query.getResultList());
					
		return claimbystSet;
		
	}
	
	@SuppressWarnings("unchecked")
    @Transactional
	public Set<Claim> findClaimsByUser_Id(int Cdno){

	        Set<Claim> claimSet;
	        claimSet = new HashSet<Claim>();
	            Query query = entityManager.createNativeQuery("select * from claim where USER_ID=:myno",Claim.class).setParameter("myno",Cdno);
	            claimSet = new HashSet(query.getResultList());
	                    
	        return claimSet;
	}
	}

	
	



