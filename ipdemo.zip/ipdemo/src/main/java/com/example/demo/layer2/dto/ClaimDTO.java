package com.example.demo.layer2.dto;

import java.io.Serializable;
import javax.persistence.*;

import com.example.demo.layer2.Iuser;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

public class ClaimDTO {

	private int claimNo;

	private String approval;

	private int claimAmt;

	private LocalDate claimDate=LocalDate.now();

	private String claimStatus;

	private String reason;

	private int userId;
	
	private int policyNo;


	public ClaimDTO() {
	}

	public int getClaimNo() {
		return this.claimNo;
	}

	public void setClaimNo(int claimNo) {
		this.claimNo = claimNo;
	}

	public String getApproval() {
		return this.approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public int getClaimAmt() {
		return this.claimAmt;
	}

	public void setClaimAmt(int claimAmt) {
		this.claimAmt = claimAmt;
	}

	public LocalDate getClaimDate() {
		return this.claimDate;
	}

	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimStatus() {
		return this.claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}
}