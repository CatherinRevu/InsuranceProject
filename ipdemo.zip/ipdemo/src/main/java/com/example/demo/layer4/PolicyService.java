package com.example.demo.layer4;

import java.util.Set;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;
import com.example.demo.layer2.Policy;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;


@Service
public interface PolicyService {//same as DeparmentDAO

	String addPolicyService(Policy pRef) throws AlreadyExistsException;  //C - add/create
	Policy findPolicyService(int pno) throws NotFoundException;    //R - find/reading
	Set<Policy> findPoliciesService();     //R - find all/reading all
	Set<Policy> findPolicyByDurationService(int pno);
	Set<Policy> findPolicyByNameService(String pname);
	String modifyPolicyService(Policy pRef) throws NotFoundException; //U - modify/update
	String removePolicyService(int pno) throws NotFoundException;
}//D - remove/delete

