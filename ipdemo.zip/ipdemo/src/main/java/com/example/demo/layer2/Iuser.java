package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the IUSER database table.
 * 
 */
@Entity
@Table(name="IUSER")
@NamedQuery(name="Iuser.findAll", query="SELECT i FROM Iuser i")
public class Iuser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="USER_ID")
	private int userId;

	private String city;

	private long contact;

	private String district;

	@Column(columnDefinition = "DATE")
	private LocalDate dob=LocalDate.now();

	private String email;

	private String name;

	private String password;

	private long pincode;

	@Column(name="STATE")
	private String state;

	private String street;
	
	//bi-directional many-to-one association to Approval
	@OneToMany(mappedBy="iuser", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Approval> approvals;
	
	//bi-directional many-to-one association to Claim
	@OneToMany(mappedBy="iuser", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Claim> claims;
	
	//bi-directional many-to-one association to PolicyManagement
	@OneToMany(mappedBy="iuser", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<PolicyManagement> policyManagements;
	
	//bi-directional many-to-one association to Vehicle
	@OneToMany(mappedBy="iuser", fetch=FetchType.EAGER,cascade = CascadeType.ALL)
	private Set<Vehicle> vehicles;

	public Iuser() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getContact() {
		return this.contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getDistrict() {
		return this.district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public LocalDate getDob() {
		return this.dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPincode() {
		return this.pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	//@JsonIgnore
	public Set<Approval> getApprovals() {
		return this.approvals;
	}

	public void setApprovals(Set<Approval> approvals) {
		this.approvals = approvals;
	}

	public Approval addApproval(Approval approval) {
		getApprovals().add(approval);
		approval.setIuser(this);

		return approval;
	}

	public Approval removeApproval(Approval approval) {
		getApprovals().remove(approval);
		approval.setIuser(null);

		return approval;
	}
	//@JsonIgnore
	public Set<Claim> getClaims() {
		return this.claims;
	}

	public void setClaims(Set<Claim> claims) {
		this.claims = claims;
	}

	public Claim addClaim(Claim claim) {
		getClaims().add(claim);
		claim.setIuser(this);

		return claim;
	}

	public Claim removeClaim(Claim claim) {
		getClaims().remove(claim);
		claim.setIuser(null);

		return claim;
	}
	//@JsonIgnore
	public Set<PolicyManagement> getPolicyManagements() {
		return this.policyManagements;
	}

	public void setPolicyManagements(Set<PolicyManagement> policyManagements) {
		this.policyManagements = policyManagements;
	}

	public PolicyManagement addPolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().add(policyManagement);
		policyManagement.setIuser(this);

		return policyManagement;
	}

	public PolicyManagement removePolicyManagement(PolicyManagement policyManagement) {
		getPolicyManagements().remove(policyManagement);
		policyManagement.setIuser(null);

		return policyManagement;
	}
	//@JsonIgnore
	public Set<Vehicle> getVehicles() {
		return this.vehicles;
	}

	public void setVehicles(Set<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Vehicle addVehicle(Vehicle vehicle) {
		getVehicles().add(vehicle);
		vehicle.setIuser(this);

		return vehicle;
	}

	public Vehicle removeVehicle(Vehicle vehicle) {
		getVehicles().remove(vehicle);
		vehicle.setIuser(null);

		return vehicle;
	}

}