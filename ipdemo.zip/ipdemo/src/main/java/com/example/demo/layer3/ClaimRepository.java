package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;
import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;

@Repository
public interface ClaimRepository {//same as DeparmentDAO

	void addClaim(Claim CdRef);   //C - add/create
	Claim findClaim(int Cdno);     //R - find/reading
	Set<Claim> findClaims();     //R - find all/reading all
	void modifyClaim(Claim CdRef); //U - modify/update
	void removeClaim(int Cdno); //D - remove/delete
	Set<Claim> findClaimsByPolicy_No(int Cdno);
	Set<Claim> findClaimsByClaimStatus(String cstatus);
	Set<Claim> findClaimsByUser_Id(int Cdno);

}
