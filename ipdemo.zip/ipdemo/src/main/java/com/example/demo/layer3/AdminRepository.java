package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.Admin;

@Repository(value="adRepo")
public interface AdminRepository {//same as DeparmentDAO

	void addAdmin(Admin AdRef);   //C - add/create
    Admin findAdmin(int Adno);    //R - find/reading
	Set<Admin> findAdmins();     //R - find all/reading all
	void modifyAdmin(Admin AdRef); //U - modify/update
	void removeAdmin(int Adno); //D - remove/delete
	Set<Admin> findAdmins(int Adno);

}