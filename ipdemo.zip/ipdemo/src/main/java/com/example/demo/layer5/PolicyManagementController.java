package com.example.demo.layer5;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.dto.PolicyManagementDTO;
import com.example.demo.layer4.IuserService;
import com.example.demo.layer4.PolicyManagementService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class PolicyManagementController {

	@Autowired
	PolicyManagementService PolManServ;
	
	@GetMapping(path="/getPolicyManager/{mypmno}")
	@ResponseBody
	public ResponseEntity<PolicyManagement> getPolicyManagement(@PathVariable("mypmno") Integer pmno) throws NotFoundException {
		System.out.println("user Controller....Understanding client and talking to service layer...");
		PolicyManagement policyManagement=null;
		
			policyManagement = PolManServ.findPolicyManagementService(pmno);
			if(policyManagement==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(policyManagement);
			}
		
	}
	
	@PostMapping(path="/addPolicyManagement")
	public String addPolicyManagement(@RequestBody PolicyManagementDTO policyManagement) {
		System.out.println("policy management Controller....Understanding client and talking to service layer...");

		
		 String stmsg = null;
		try {
			System.out.println(policyManagement.getUserId());
			System.out.println(policyManagement.getPolicyId());
			System.out.println(policyManagement.getRegNo());
			stmsg = PolManServ.addPolicyManagementService(policyManagement);
		} 
	 catch (AlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	@PutMapping(path="/modifyPolicyManagement")
	public String modifyPolicyManagement(@RequestBody PolicyManagement policyManagement)throws NotFoundException {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = PolManServ.modifyPolicyManagementService(policyManagement);
		    } 
		catch (NotFoundException e) 
		{
            return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("controller is saying: "+stmsg);
		  return stmsg;
		
	}
	
	@GetMapping(path="/getPolicyOfId/{uid}")
	@ResponseBody
	public ResponseEntity<Set<PolicyManagement>> getPolicyManagementsbyUserId(@PathVariable("uid")Integer pmno) throws NotFoundException {
		System.out.println("policy management Controller....Understanding client and talking to service layer...");
		Set<PolicyManagement> policyManagement=null;
		policyManagement = PolManServ.findPolicyManagementsbyUserIdServices(pmno);
		if(policyManagement==null)
		{ return ResponseEntity.notFound().build();
		
		}
		else {
			return ResponseEntity.ok(policyManagement);
		}
		
		
		
	}
	
	
}