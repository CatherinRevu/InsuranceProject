package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the APPROVAL database table.
 * 
 */
@Entity
@Table(name="APPROVAL")
@NamedQuery(name="Approval.findAll", query="SELECT a FROM Approval a")
public class Approval implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="APPROVAL_NO")
	private int approvalNo;

	@Column(name="CLAIM_APPROVAL")
	private String claimApproval;

	@Column(name="CLAIM_STATUS")
	private String claimStatus;

	//bi-directional many-to-one association to Admin
	@ManyToOne
	@JoinColumn(name="ADMIN_ID")
	private Admin admin;

	//bi-directional many-to-one association to Iuser
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Iuser iuser;

	//bi-directional one-to-one association to Claim
	@OneToOne
	@JoinColumn(name="CLAIM_NO")
	private Claim claim;

	//bi-directional one-to-one association to PolicyManagement
	@OneToOne
	@JoinColumn(name="POLICY_NO")
	private PolicyManagement policyManagement;
	

	public Approval() {
	}

	public int getApprovalNo() {
		return this.approvalNo;
	}

	public void setApprovalNo(int approvalNo) {
		this.approvalNo = approvalNo;
	}

	public String getClaimApproval() {
		return this.claimApproval;
	}

	public void setClaimApproval(String claimApproval) {
		this.claimApproval = claimApproval;
	}

	public String getClaimStatus() {
		return this.claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}
	@JsonIgnore
	public Admin getAdmin() {
		return this.admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}
	
	@JsonIgnore
	public Iuser getIuser() {
		return this.iuser;
	}

	public void setIuser(Iuser iuser) {
		this.iuser = iuser;
	}
	
	public Claim getClaim() {
		return this.claim;
	}

	public void setClaim(Claim claim) {
		this.claim = claim;
	}
	
	public PolicyManagement getPolicyManagement() {
		return this.policyManagement;
	}

	public void setPolicyManagement(PolicyManagement policyManagement) {
		this.policyManagement = policyManagement;
	}

}