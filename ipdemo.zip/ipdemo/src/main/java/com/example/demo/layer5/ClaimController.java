package com.example.demo.layer5;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Claim;
import com.example.demo.layer2.dto.ClaimDTO;
import com.example.demo.layer4.ClaimService;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@CrossOrigin(origins="http://localhost:4200")
@RestController  //REpresentational State Transfer html xml json
public class ClaimController {

	@Autowired
	ClaimService claimServ;
	
	@GetMapping(path="/getclaim/{myclaim}")
	@ResponseBody
	public ResponseEntity<Claim> getClaim(@PathVariable("myclaim") Integer Cdno) throws NotFoundException {
		System.out.println("Claim Controller....Understanding client and talking to service layer...");
		Claim claim=null;
		
			claim = claimServ.findClaimService(Cdno);
			if(claim==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(claim);
			}
		
	}
	
	@PostMapping(path="/addclaim")
	public String addClaim(@RequestBody ClaimDTO claim) {
		System.out.println("Claim Controller....Understanding client and talking to service layer...");
		
		
		
		 String stmsg = null;
		try {
			stmsg = claimServ.addClaimService(claim);
		} 
	 catch (AlreadyExistsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
			return e.getMessage();
		}
		System.out.println("controller printing"+stmsg);
		  return stmsg;
		
	}
	@PutMapping(path="/modifyclaim")
	public String modifyClaim(@RequestBody Claim claim)throws NotFoundException {
		System.out.println("Claim Controller....Understanding client and talking to service layer...");
		 String stmsg = null;
		try {
			stmsg = claimServ.modifyClaimService(claim);
		} 
		catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		  return stmsg;
		
	}
	@GetMapping(path="/getclaims")
	@ResponseBody
	public Set<Claim> getAllPolicies() {
		System.out.println("Department Controller....Understanding client and talking to service layer...");
		Set<Claim> claimset = claimServ.findClaimsService();
		return claimset;
		
	}
	@GetMapping(path="/getclaimbyclaimstat/{mystat}")
	@ResponseBody
	public ResponseEntity<Set<Claim>> getClaimByClaimStatus(@PathVariable("mystat") String cstatus) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Set<Claim> claim=null;
		
			claim = claimServ.findClaimsByClaimStatusService(cstatus);
			if(claim==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(claim);
			}
		
	}
	@GetMapping(path="/getclaimbypolicyno/{mypolno}")
	@ResponseBody
	public ResponseEntity<Set<Claim>> getClaimByPolicyno(@PathVariable("mypolno") Integer Cdno) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Set<Claim> claim=null;
		
			claim = claimServ.findClaimsByPolicy_NoService(Cdno);
			if(claim==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(claim);
			}
		
	}
	@GetMapping(path="/getclaimbyuserid/{myuid}")
	@ResponseBody
	public ResponseEntity<Set<Claim>> getClaimByUserId(@PathVariable("myuid") Integer Cdno) throws NotFoundException {
		System.out.println("Policy Controller....Understanding client and talking to service layer...");
		Set<Claim> claim=null;
		
			claim = claimServ.findClaimsByUser_IdService(Cdno);
			if(claim==null)
			{ return ResponseEntity.notFound().build();
			
			}
			else {
				return ResponseEntity.ok(claim);
			}
		
	}
	
}