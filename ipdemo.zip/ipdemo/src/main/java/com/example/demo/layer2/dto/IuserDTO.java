package com.example.demo.layer2.dto;

import java.io.Serializable;
import javax.persistence.*;

import com.example.demo.layer2.Approval;
import com.example.demo.layer2.Claim;
import com.example.demo.layer2.PolicyManagement;
import com.example.demo.layer2.Vehicle;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the IUSER database table.
 * 
 */
public class IuserDTO{

	private int userId;

	private String city;

	private long contact;

	private String district;

	private LocalDate dob=LocalDate.now();

	private String email;

	private String name;

	private String password;

	private long pincode;

	private String state;

	private String street;
	

	public IuserDTO() {
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getContact() {
		return this.contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getDistrict() {
		return this.district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public LocalDate getDob() {
		return this.dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public long getPincode() {
		return this.pincode;
	}

	public void setPincode(long pincode) {
		this.pincode = pincode;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return this.street;
	}

	public void setStreet(String street) {
		this.street = street;
	}



}