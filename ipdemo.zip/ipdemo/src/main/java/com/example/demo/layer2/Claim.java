package com.example.demo.layer2;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;


/**
 * The persistent class for the CLAIM database table.
 * 
 */
@Entity
@Table(name="CLAIM")
@NamedQuery(name="Claim.findAll", query="SELECT c FROM Claim c")
public class Claim {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="CLAIM_NO")
	private int claimNo;

	private String approval;

	@Column(name="CLAIM_AMT")
	private int claimAmt;

	@Column(columnDefinition="DATE", name="CLAIM_DATE")
	private LocalDate claimDate=LocalDate.now();

	@Column(name="CLAIM_STATUS")
	private String claimStatus;

	private String reason;

	//bi-directional many-to-one association to Iuser
	@ManyToOne
	@JoinColumn(name="USER_ID")
	private Iuser iuser;
	
	@ManyToOne
	@JoinColumn(name="POLICY_NO")
	private PolicyManagement policyManagement;

	//bi-directional one-to-one association to PolicyManagement
	/*
	 * @OneToOne(mappedBy="claim") private PolicyManagement policyManagement;
	 */

	

	//bi-directional one-to-one association to Approval
	@OneToOne(mappedBy="claim")
	private Approval approvalBean;

	public Claim() {
	}

	public int getClaimNo() {
		return this.claimNo;
	}

	public void setClaimNo(int claimNo) {
		this.claimNo = claimNo;
	}

	public String getApproval() {
		return this.approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public int getClaimAmt() {
		return this.claimAmt;
	}

	public void setClaimAmt(int claimAmt) {
		this.claimAmt = claimAmt;
	}

	public LocalDate getClaimDate() {
		return this.claimDate;
	}

	public void setClaimDate(LocalDate claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimStatus() {
		return this.claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public String getReason() {
		return this.reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	
	@JsonIgnore
	public Iuser getIuser() {
		return this.iuser;
	}

	public void setIuser(Iuser iuser) {
		this.iuser = iuser;
	}

	

	  
	public Approval getApprovalBean() {
		return this.approvalBean;
	}

	public void setApprovalBean(Approval approvalBean) {
		this.approvalBean = approvalBean;
	}
	@JsonIgnore
	public PolicyManagement getPolicyManagement() {
		return policyManagement;
	}

	public void setPolicyManagement(PolicyManagement policyManagement) {
		this.policyManagement = policyManagement;
	}
}