package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Iuser;
import com.example.demo.layer2.Policy;
import com.example.demo.layer2.Vehicle;
import com.example.demo.layer2.dto.VehicleDTO;
import com.example.demo.layer3.IuserRepository;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer3.VehicleRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class VehicleServiceImpl implements VehicleService{//isA
	
	@Autowired
	VehicleRepository vRepo;
	@Autowired
	IuserRepository iuserRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addVehicleService(VehicleDTO vDTO) throws AlreadyExistsException {//usesA
		try {
			Vehicle v1=new Vehicle();
			v1.setTypeOfVehicle(vDTO.getTypeOfVehicle());
			v1.setModel(vDTO.getModel());
			v1.setPurchaseDate(vDTO.getPurchaseDate());
			v1.setAge(vDTO.getAge());
			v1.setEngType(vDTO.getEngType());
			v1.setDriversLicense(vDTO.getDriversLicense());
			v1.setEngNo(vDTO.getEngNo());
			v1.setChasisNo(vDTO.getChasisNo());
			
			Iuser user=iuserRepo.findIuser(vDTO.getUserId());
			user.getVehicles().add(v1);
			v1.setIuser(user);
			iuserRepo.modifyIuser(user);
			
			//v1.getIuser().getUserId();
			//vRepo.addVehicle(vRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("Vehicle already exists");
		}
		return "Vehicle added sucessfully";
		

	}
	
	@Override
	public Vehicle findVehicleService(int vno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Policy pObj = entityManager.find(Policy.class, pno);
		System.out.println("found Vehicle");
		
		return vRepo.findVehicle(vno);
		
	}

	@Override
	public Set<Vehicle> findVehicleService() {
     			
		return vRepo.findVehicles();
	}

	@Override
	public String modifyVehicleService(Vehicle vRef) throws NotFoundException {
		Vehicle v = vRepo.findVehicle(vRef.getRegNo());
		if (v!=null) {
			vRepo.modifyVehicle(vRef);
		}
		else
		{
			throw new NotFoundException("Vehicle Not Found");
		}
     return"Vehicle modified sucessfully";
	}

	@Override
	public String removeVehicleService(int Regno) throws NotFoundException {
		
		Vehicle v = vRepo.findVehicle(Regno);
		if (v!=null) {
			vRepo.removeVehicle(v.getRegNo());
		}
		else
		{
			throw new NotFoundException("Vehicle Not Found");
		}
     return "Vehicle deleted sucessfully";
	}

}
