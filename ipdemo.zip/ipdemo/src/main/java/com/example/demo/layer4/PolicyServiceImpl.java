package com.example.demo.layer4;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Policy;
import com.example.demo.layer3.PolicyRepository;
import com.example.demo.layer4.exceptions.AlreadyExistsException;
import com.example.demo.layer4.exceptions.NotFoundException;

@Service
public class PolicyServiceImpl implements PolicyService{//isA
	
	@Autowired
	PolicyRepository pRepo;

	
	@Override//no need of begin transaction and commit rollback
	public String addPolicyService(Policy pRef) throws AlreadyExistsException {//usesA
		try {
			System.out.println("printing...");
			pRepo.addPolicy(pRef);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new AlreadyExistsException("Policy already exists");
		}
		return "policy added sucessfully";
		

	}
	
	@Override
	public Policy findPolicyService(int pno) throws NotFoundException {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Policy pObj = entityManager.find(Policy.class, pno);
		System.out.println("found policy");
		
		return pRepo.findPolicy(pno);
		
	}

	@Override
	public Set<Policy> findPoliciesService() {
     			
		return pRepo.findPolicies();
	}
	@Override
	public Set<Policy> findPolicyByDurationService(int pno) {
     			
		return pRepo.findPolicyByDuration(pno);
	}
	@Override
	public Set<Policy> findPolicyByNameService(String pname) {
     			
		return pRepo.findPolicyByName(pname);
	}

	@Override
	public String modifyPolicyService(Policy pRef) throws NotFoundException {
		Policy p = pRepo.findPolicy(pRef.getPolicyId());
		if (p!=null) {
			pRepo.modifyPolicy(pRef);
		}
		else
		{
			throw new NotFoundException("policy Not Found");
		}
     return"policy modified sucessfully";
	}

	@Override
	public String removePolicyService(int pno) throws NotFoundException {
		
		Policy p = pRepo.findPolicy(pno);
		if (p!=null) {
			pRepo.removePolicy(p.getPolicyId());
		}
		else
		{
			throw new NotFoundException("policy Not Found");
		}
     return "policy deleted sucessfully";
	}
	

}


