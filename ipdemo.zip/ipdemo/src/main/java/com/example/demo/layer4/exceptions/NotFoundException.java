package com.example.demo.layer4.exceptions;



@SuppressWarnings("serial")
public class NotFoundException extends Throwable{
	public NotFoundException(String msg) {
		super(msg);
	}
}
