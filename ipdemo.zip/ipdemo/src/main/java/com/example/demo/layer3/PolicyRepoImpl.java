package com.example.demo.layer3;

import java.util.Set;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.Policy;
import com.example.demo.layer2.PolicyManagement;




@Repository("pRepo")
public class PolicyRepoImpl implements PolicyRepository {//isA
	
	
	@PersistenceContext
	 EntityManager entityManager;//auto injected by spring by reading 
										//persistance.xml file
	
	@Transactional//no need of begin transaction and commit rollback
	public void addPolicy(Policy pRef) {//usesA
		entityManager.persist(pRef);
		

	}
	
	@Transactional
	public Policy findPolicy(int pno) {//producesA Department obj
		//System.out.println("Department repo....NO scope of bussiness logic here...");
		//Policy PObj = entityManager.find(Policy.class, pno);
		System.out.println("found policy");
		return entityManager.find(Policy.class, pno);
		
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Policy> findPolicies() {
		Set<Policy> policySet;
		policySet = new HashSet<Policy>();
		
			String queryString = "from Policy";
			Query query = entityManager.createQuery(queryString);
			policySet =new HashSet(query.getResultList());
					
		return policySet;
		
	}

	@Transactional
	public void modifyPolicy(Policy pRef) {
		entityManager.merge(pRef);

	}

	@Transactional
	public void removePolicy(int pno) {
		Policy pTemp = entityManager.find(Policy.class,pno);
		entityManager.remove(pTemp);
		
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public Set<Policy> findPolicyByDuration(int pno){
		Set<Policy> pSet;
		pSet = new HashSet<Policy>();
		Query query = entityManager.createNativeQuery("select * from policy where duration=:mydur",Policy.class).setParameter("mydur", pno);
		pSet =new HashSet(query.getResultList());
					
		return pSet;
		
	}
	public Set<Policy>  findPolicyByName(String pname) {
		System.out.println("found policy");
		Set<Policy> pSet;
		pSet = new HashSet<Policy>();
		Query query=entityManager.createNativeQuery("select * from policy where policy_name=:name",Policy.class).setParameter("name",pname);
		pSet = new HashSet(query.getResultList());
		return pSet;
	}
}

