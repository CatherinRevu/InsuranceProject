import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { vehicle, VehicleDTO } from './vehicle';


@Injectable({
  providedIn: 'root'
})
export class VehicleService {

   constructor(private myHttp: HttpClient) { }
  addVehicleService(myVehicle: VehicleDTO){
    return this.myHttp.post("http://localhost:8080/addVehicle",myVehicle,{responseType:'text'});
   }
  
   findVehicleService(myVehicle: vehicle){
    return this.myHttp.post("http://localhost:8080/findVehicle",myVehicle,{responseType:'text'});
   }

   modifyVehicleService(myVehicle: vehicle){
    return this.myHttp.put("http://localhost:8080/modifyVehicle",myVehicle,{responseType:'text'});
   }

   removeVehicleService(myVehicle: vehicle){
    return this.myHttp.post("http://localhost:8080/removeVehicle",myVehicle,{responseType:'text'});
   }



}