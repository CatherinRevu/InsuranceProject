import { TestBed } from '@angular/core/testing';

import { PolicyManagementService } from './policy_management.service';

describe('PolicyManagementService', () => {
  let service: PolicyManagementService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PolicyManagementService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
