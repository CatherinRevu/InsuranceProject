export class adimin{
    admin_id:number |undefined;
    password:string |undefined;
    name:string |undefined;
    }