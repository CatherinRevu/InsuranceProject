import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { policy_management, policy_managementDTO } from '../policy_management';
import { PolicyManagementService } from '../policy_management.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 myPolMan:policy_managementDTO=new policy_managementDTO();
 uid=0;
 lis=[];

  constructor(private router: Router ,private ccs:PolicyManagementService) { }
  click1(): void {
    this.router.navigate(["buy-policy"]);
  }
  click2(): void {
    this.router.navigate(["renew"]);
  }
  click3(): void {
    this.router.navigate(["claim"]);
  }
  view(){
    //this.router.navigate(["display"])

  }
  isShow=true;
  e:policy_management=new policy_management();
  getPolicyManagementsbyUserId(uid: number){
    this.ccs.getPolicyManagementsbyUserIdService(uid).subscribe((data)=>{
      if(data!=null){
        this.e=data;
      }
      else {
        alert("unable to fetch");
      }
    }
    )
}


  ngOnInit(): void {
    
  }
  visibility(): void{
    this.isShow=!this.isShow;

  }
 

}
