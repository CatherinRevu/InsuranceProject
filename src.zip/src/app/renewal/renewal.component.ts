import { Component, OnInit } from '@angular/core';
import { policy_managementDTO } from '../policy_management';
import { PolicyManagementService } from '../policy_management.service';

@Component({
  selector: 'app-renewal',
  templateUrl: './renewal.component.html',
  styleUrls: ['./renewal.component.css']
})
export class RenewalComponent implements OnInit {
  myPolMan:policy_managementDTO=new policy_managementDTO();

  constructor(private ccs:PolicyManagementService) { }

  ngOnInit(): void {
  }
  addPolicyManagement(myPolMan: policy_managementDTO){
    this.ccs.addPolicyManagementService(this.myPolMan).subscribe((data: string)=>{
      if(data!=null){
        alert("you have renewed your insurance");
      }},
      (err: any)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )
    }
}
