import { vehicle } from "./vehicle";

export class iuser{
    userId:number |undefined;
    name:string|undefined;
    email:string|undefined;
    password:string|undefined;
    dob:Date|undefined;
    contact:number |undefined;
    street:string|undefined;
    city:string|undefined;
    district:string|undefined;
    state:string|undefined;
    pincode:number|undefined;
    vehicle:vehicle[]|undefined;

}
export class uservalidate
{
    userId:number |undefined;
    password:string|undefined;
}