import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { HomeComponent } from './home/home.component';
import { BuyPolicyComponent } from './buy-policy/buy-policy.component';
import { RenewalComponent } from './renewal/renewal.component';
import { ClaimComponent } from './claim/claim.component';
import { ChoosePolicyComponent } from './choose-policy/choose-policy.component';
import { SelectPolicyComponent } from './select-policy/select-policy.component';
import { PurchaseComponent } from './purchase/purchase.component';
import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
  //{path:'',component:LoginComponent},
  {path:'sign-up',component:SignUpComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'buy-policy',component:BuyPolicyComponent},
  {path:'renew',component:RenewalComponent},
  {path:'claim',component:ClaimComponent},
  {path:'choose-policy',component:ChoosePolicyComponent},
  {path:'select-policy',component:SelectPolicyComponent},
  {path:'purchase',component:PurchaseComponent},
  {path:'admin',component:AdminComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [SignUpComponent,LoginComponent,HomeComponent,BuyPolicyComponent,RenewalComponent,ClaimComponent,ChoosePolicyComponent,PurchaseComponent,AdminComponent]
