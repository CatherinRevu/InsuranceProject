import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-select-policy',
  templateUrl: './select-policy.component.html',
  styleUrls: ['./select-policy.component.css']
})
export class SelectPolicyComponent implements OnInit {
  //Policy =["OWE_4_WHEELER_1","OWE_4_WHEELER_2","OWE_4_WHEELER_3"]

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  next(): void{
    this.router.navigate(["purchase"]);
  }


}
