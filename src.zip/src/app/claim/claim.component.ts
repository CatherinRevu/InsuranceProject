import { Component, OnInit } from '@angular/core';
import { claim, claimDTO } from '../claim';
import { ClaimService } from '../claim.service';

@Component({
  selector: 'app-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.css']
})
export class ClaimComponent implements OnInit {

  constructor(private ccs:ClaimService) { }

  ngOnInit(): void {
  }
  myclaim: claimDTO= new claimDTO();
  findClaim(myclaim: number){
      this.ccs.findClaimService(myclaim).subscribe((data)=>{
        if (data!=null) 
        {this.myclaim=data;}
        else{
          alert('unable to featch');
        }
        })
  }
  
  addClaim(myclaim:claimDTO){
    this.ccs.addClaimService(myclaim).subscribe((data)=>{
      if(data!=null){
        alert("adding is successful");
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )

  }
  modifyClaim(myclaim:claim){
    this.ccs.modifyClaimService(myclaim).subscribe((data)=>{
      if(data!=null){
        alert("Modification successful");
      }},
      (err)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )

  }
  
  findClaimsByPolicy_No(myclaim: number){
      this.ccs.findClaimsByPolicy_NoService(myclaim).subscribe((data)=>{
        if (data!=null) 
        {this.myclaim=data;}
        else{
          alert('unable to featch');
        }
        })
  }
  findClaimsByClaimStatus(myclaim1: string){
    this.ccs.findClaimsByClaimStatusService(myclaim1).subscribe((data)=>{
      if (data!=null) 
      {this.myclaim=data;}
      else{
        alert('unable to featch');
      }
      })
}
findClaimsByUser_Id(myclaim2: number){
  this.ccs.findClaimsByUser_IdService(myclaim2).subscribe((data)=>{
    if (data!=null) 
    {this.myclaim=data;}
    else{
      alert('unable to featch');
    }
    })
}
}