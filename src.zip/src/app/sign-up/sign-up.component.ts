import { Component, OnInit } from '@angular/core';
import { iuser } from '../iuser';
import { IuserService } from '../iuser.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {



  constructor(private ccs:IuserService) { }

  ngOnInit(): void {}

    myUser:iuser=new iuser();
    addIuser(myUser: iuser){
      this.ccs.addIuserService(this.myUser).subscribe((data: string)=>{
        if(data!=null){
          alert("adding is successful");
        }},
        (err)=>{
          alert("some thing went wrong");
          console.log(err);
        }
      
      )
      }
    }



