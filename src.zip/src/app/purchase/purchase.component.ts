import { Component, Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PolicyManagementService } from '../policy_management.service';
import { policy_management, policy_managementDTO } from '../policy_management';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.component.html',
  styleUrls: ['./purchase.component.css']
})

export class PurchaseComponent implements OnInit {

  myPolMan:policy_managementDTO=new policy_managementDTO();
  uid=0;

  constructor(private router: Router,private ccs:PolicyManagementService) { }

  ngOnInit(): void {}

  addPolicyManagement(myPolMan: policy_managementDTO){
    this.ccs.addPolicyManagementService(this.myPolMan).subscribe((data: string)=>{
      if(data!=null){
        alert("you have insured your vehicle");
      }},
      (err: any)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )
    }

    
    getPolicyManagementsbyUserId(uid: number){
      this.ccs.getPolicyManagementsbyUserIdService(uid).subscribe((data)=>{
        if(data!=null){
          this.myPolMan=data;
        }
        else {
          alert("unable to fetch");
        }
      }
      )
}


    
      modifyPolicyManagement(myPolMan: policy_managementDTO){
        this.ccs.modifyPolicyManagementService(this.myPolMan).subscribe((data: string)=>{
          if(data!=null){
            alert("adding is successful");
          }},
          (err: any)=>{
            alert("some thing went wrong");
            console.log(err);
          }
        
        )
        }
    
   

}
