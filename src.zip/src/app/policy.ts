export class policy{
    policy_id:number |undefined;
    policy_name:string |undefined;
    duration:number |undefined;
    }