import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { vehicle, VehicleDTO } from '../vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-buy-policy',
  templateUrl: './buy-policy.component.html',
  styleUrls: ['./buy-policy.component.css']
})
export class BuyPolicyComponent implements OnInit {
 
  myVehicle:VehicleDTO=new VehicleDTO();

  constructor(private router: Router,private ccs:VehicleService) { }
  policy(): void {
    if(this.myVehicle.typeOfVehicle == '2-Wheeler')
    {
       this.router.navigate(["choose-policy"]);
    }
    if(this.myVehicle.typeOfVehicle == '4-Wheeler')
    {
       this.router.navigate(["select-policy"]);
    }

  }

  ngOnInit(): void {}

  
  addVehicle(myVehicle: VehicleDTO){
    this.ccs.addVehicleService(this.myVehicle).subscribe((data: string)=>{
      if(data!=null){
        alert("adding is successful");
      }},
      (err: any)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )
    }

    
  findVehicle(myVehicle: VehicleDTO){
    this.ccs.findVehicleService(this.myVehicle).subscribe((data: string)=>{
      if(data!=null){
        alert("found");
      }},
      (err: any)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )
    }


    
  modifyVehicle(myVehicle: VehicleDTO){
    this.ccs.modifyVehicleService(this.myVehicle).subscribe((data: string)=>{
      if(data!=null){
        alert("Modified Successfully");
      }},
      (err: any)=>{
        alert("some thing went wrong");
        console.log(err);
      }
    
    )
    }

    
    removeVehicle(myVehicle: VehicleDTO){
      this.ccs.removeVehicleService(this.myVehicle).subscribe((data: string)=>{
        if(data!=null){
          alert("removed is successful");
        }},
        (err: any)=>{
          alert("some thing went wrong");
          console.log(err);
        }
      
      )
      }
}