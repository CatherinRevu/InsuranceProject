import { Component, OnInit } from '@angular/core';
import { iuser } from '../iuser';
import { IuserService } from '../iuser.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  myUser: iuser=new iuser();
  
  constructor(private ccs: IuserService) { }

  ngOnInit(): void {
  }
  
  findIusersByUser_Id(uid: number){
    this.ccs.findIusersByUser_IdService(uid).subscribe((data)=>{
      if(data!=null)
      {
        this.myUser=data;
      }
        else
        {
          alert('unable to featch');
        }
      })
}
}
