import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {MatDatepickerModule} from '@angular/material/datepicker';

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { BuyPolicyComponent } from './buy-policy/buy-policy.component';
import { RenewalComponent } from './renewal/renewal.component';
import { ClaimComponent } from './claim/claim.component';
import {HttpClientModule} from '@angular/common/http'

import { MatFormFieldModule } from '@angular/material/form-field';
import { MainpageComponent } from './mainpage/mainpage.component';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule,} from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

import {MatListModule} from '@angular/material/list';
import { ChoosePolicyComponent } from './choose-policy/choose-policy.component';
import { SelectPolicyComponent } from './select-policy/select-policy.component';
import { DemoMaterialModule } from './material-module';
import { PurchaseComponent } from './purchase/purchase.component';
import { AdminComponent } from './admin/admin.component';
;


@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    BuyPolicyComponent,
    RenewalComponent,
    ClaimComponent,
    MainpageComponent,
    ChoosePolicyComponent,
    SelectPolicyComponent,
    PurchaseComponent,
    AdminComponent,
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpClientModule,
    DemoMaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
