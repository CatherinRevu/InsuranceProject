import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-choose-policy',
  templateUrl: './choose-policy.component.html',
  styleUrls: ['./choose-policy.component.css']
})
export class ChoosePolicyComponent implements OnInit {

  constructor(private router: Router) { }
  Policy =["OWE_2_WHEELER_1","OWE_2_WHEELER_2","OWE_2_WHEELER_3"]
  ngOnInit(): void {
  }
  next(): void{
    this.router.navigate(["purchase"]);
  }
}
