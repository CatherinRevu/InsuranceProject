import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { claim, claimDTO } from './claim';

@Injectable({
  providedIn: 'root'
})
export class ClaimService {

  constructor(private myHttp: HttpClient) { }
  addClaimService(myclaim: claimDTO){
    return this.myHttp.post("http://localhost:8080/addclaim",myclaim,{responseType:'text'});
  }
  findClaimService(myclaim: number): Observable<claim> {
   return this.myHttp.get<claim>("http://localhost:8080/getclaim/"+myclaim);
  }
  modifyClaimService(myclaim: claim)  {
  return this.myHttp.put("http://localhost:8080/modifyclaim",myclaim,{responseType:'text'});
  }
  findClaimsByPolicy_NoService(myclaim: number): Observable<claim> {
    return this.myHttp.get<claim>("http://localhost:8080/getclaimbypolicyno/"+myclaim);
   }
   findClaimsByClaimStatusService(myclaim: string): Observable<claim> {
    return this.myHttp.get<claim>("http://localhost:8080/getclaimbyclaimstat/"+myclaim);
   }
   findClaimsByUser_IdService(myclaim: number): Observable<claim> {
    return this.myHttp.get<claim>("http://localhost:8080/getclaimbyuserid/"+myclaim);
   }
}