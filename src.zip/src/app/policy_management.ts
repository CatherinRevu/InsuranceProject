export class policy_management{
    policyId:number |undefined;
    regNo:number |undefined;
    amount:number |undefined;
    payment:number |undefined;
    policyNo:number |undefined;
    policyIssueDate:Date |undefined;
    duration:number |undefined;
    policyStatus:string |undefined;
    policyExpireDate:Date |undefined;
    userId:number |undefined;
    }
    export class policy_managementDTO{

    policyId:number |undefined;
    regNo:number |undefined;
    amount:number |undefined;
    payment:number |undefined;
    policyNo:number |undefined;
    policyIssueDate:Date |undefined;
    duration:number |undefined;
    policyStatus:string |undefined;
    policyExpireDate:Date |undefined;
    userId:number |undefined;
    }