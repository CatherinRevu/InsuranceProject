import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { policy_management, policy_managementDTO } from './policy_management';

@Injectable({
  providedIn: 'root'
})
export class PolicyManagementService {

  
  constructor(private myHttp: HttpClient) { }
  getPolicyManagementsbyUserIdService(uid: number): Observable<policy_management>{
  
    return this.myHttp.get<policy_management>("http://localhost:8080/getPolicyOfId/"+uid);
  }
  addPolicyManagementService(myPolMan: policy_managementDTO){
    return this.myHttp.post("http://localhost:8080/addPolicyManagement",myPolMan,{responseType:'text'});
  }
  modifyPolicyManagementService(myPolMan: policy_management){
    return this.myHttp.put("http://localhost:8080/modifyPolicyManagement",myPolMan,{responseType:'text'});
  }
}
