import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { iuser } from './iuser';

@Injectable({
  providedIn: 'root'
})
export class IuserService {
  
  constructor(private myHttp: HttpClient) { }
  addIuserService(myUser: iuser){
    return this.myHttp.post("http://localhost:8080/addIuser",myUser,{responseType:'text'});
  }
  findUserByUserIDPasswordService(User1: iuser): Observable<iuser> {
    return this.myHttp.post<iuser>("http://localhost:8080/loginUser",User1);  
  }
  findIusersByUser_IdService(myUser: number): Observable<iuser> {
    return this.myHttp.get<iuser>("http://localhost:8080/getiuserbyuserid/"+myUser);
   }
  }



