export class claim{
    claimNo:number |undefined;
    reason:string |undefined;
    policyNo:number |undefined;
    claimDate:Date |undefined;
    claimStatus:string |undefined;
    approval:string |undefined;
    claimAmt:number |undefined;
    userId:number |undefined;
    }
    export class claimDTO{
    claimNo:number |undefined;
    reason:string |undefined;
    policyNo:number |undefined;
    claimDate:Date |undefined;
    claimStatus:string |undefined;
    approval:string |undefined;
    claimAmt:number |undefined;
    userId:number |undefined;
    }