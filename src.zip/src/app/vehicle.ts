
export class vehicle{
    regNo:number|undefined;
    typeOfVehicle: string |undefined;
    model:string|undefined;
    engType:string|undefined;
    driversLicense:string|undefined;
    purchaseDate:Date|undefined;
    age:number |undefined;
    engNo:string|undefined;
    chasisNo:string|undefined;
    //userId:number|undefined;

}
export class VehicleDTO{
    regNo:number|undefined;
    typeOfVehicle: string |undefined;
    model:string|undefined;
    engType:string|undefined;
    driversLicense:string|undefined;
    purchaseDate:Date|undefined;
    age:number |undefined;
    engNo:string|undefined;
    chasisNo:string|undefined;
    userId:number|undefined;
}