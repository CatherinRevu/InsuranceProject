export class approval{
    approval_no:number |undefined;
    admin_id:number |undefined;
    policy_no:number |undefined;
    claim_no:number |undefined;
    claim_approval:string |undefined;
    claim_status:string |undefined;
    user_id:number |undefined;
    }