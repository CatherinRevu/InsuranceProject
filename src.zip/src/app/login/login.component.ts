import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { iuser } from '../iuser';
import { IuserService } from '../iuser.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  prompt1='Enter User ID';
  prompt2='Enter Password';

  userId: Number | undefined;
  password: String | undefined;
  
  constructor(private router: Router,private ccs:IuserService) { }
  ngOnInit(): void {

  }

  signup(): void {
    this.router.navigate(["sign-up"]);
  }
  User1: iuser  =new iuser();
    loginValidate() {
     this.ccs.findUserByUserIDPasswordService(this.User1).subscribe((data: iuser)=>{
       //if(this.userId==101 && this.password=="suresh1")
       //{
       // this.router.navigate(['/admin']);
       //}

       if (data!=null) 
       {this.User1=data;
       console.log("done");


      // this.router.navigate(['/adminhome']);
       alert('login succesfull');
       this.router.navigate(["home"]);
       }
       else{
         alert('login denied');
       }
       })

  

      }
    }
